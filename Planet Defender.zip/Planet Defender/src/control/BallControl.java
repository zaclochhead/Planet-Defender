package control;

import model.*;

import java.awt.*;

/**
 * The ball control class handles all ball movements and collisions
 *
 */
public class BallControl {
	private PowerUp powerUp;
	private Ball gameBall;
	private GameBoard gameBoard;
	private boolean negativeReflect;
	private boolean positiveReflect;
	private boolean pass;
	private PlayerAvatar p1,p2,p3,p4;
	private GameControl gameControl;

	int timesStuck;

	public BallControl(Ball ball,GameBoard gameBoard,PlayerAvatar p1,
					   PlayerAvatar p2,PlayerAvatar p3,PlayerAvatar p4, GameControl gameControl){
		this.gameBall = ball;
		this.gameBoard = gameBoard;
		this.p1=p1;
		this.p2=p2;
		this.p3=p3;
		this.p4=p4;
		this.gameControl = gameControl;
	}
	//adds the current powerup to this class 
	public void addPowerUp(PowerUp powerUp){
		this.powerUp = powerUp;
	}
	
	//moves the ball appropriately each tick
	public void move(){
		//a sprite object to control the intersections 
		Sprite sprite = new Sprite();

		outerloop:
		//loop throught the gameboard
		for (int x = 0; x <1024; x++){
	        for (int y = 0; y < 768; y++) {
	        	//if the balls colliding with the 0 boundaries 
	        	if((gameBall.getXPos()+gameBall.getXVelocity())<=0 
	        	  || (gameBall.getYPos()+gameBall.getYVelocity())<=0){
	        		gameControl.countDownSound.play();
	    	    	negativeReflect = true;
	    	    	break outerloop;
	    	    }
	    		//if gameBall x or y collides with positive boundary 
	    		else if((gameBall.getXPos()+gameBall.getXVelocity())>=(1024-gameBall.getWidth()) 
	    			   || (gameBall.getYPos()+gameBall.getYVelocity())>=(768-gameBall.getHeight())){
					gameControl.countDownSound.play();
	        		positiveReflect = true;
	    			break outerloop;
	    		}
	    				    			
	            //if the balls colliding with a wall 
	    		else if((gameBoard.getAt(x,y) != null) && (gameBoard.getAt(x,y).isAlive()) 
	    				&& ((gameBoard.getAt(x,y).getObjectType() == ObjectType.WALL))) {
	            	if((sprite.getBoundary(gameBall).intersects(sprite.getBoundary(gameBoard.getAt(x, y))))){
	            			//reflect the ball appropriately 
	            			gameBall.objectReflect(gameBoard.getAt(x, y));
							gameControl.wallDeath.play();
							//destroy the wall hit
							if(gameBoard.getAt(x, y).getObjectType()!=ObjectType.BALL){
	            				gameBoard.getAt(x, y).setDead();
	            			}
							//decrement the number of players wall 
                            gameControl.decrementPlayerWalls(gameBoard.getAt(x, y).getPlayer());
                            //increment the score of the player that hit the ball last 
                            if(gameBall.getLastHitBy()!=null){
                                if((gameBall.getLastHitBy()==PlayerNumberType.PLAYER_ONE) &&
										(gameBoard.getAt(x,y).getPlayer() != PlayerNumberType.PLAYER_ONE)){
                                    p1.incrementScore();
	            				}
	            				else if((gameBall.getLastHitBy()==PlayerNumberType.PLAYER_TWO)&&
										(gameBoard.getAt(x,y).getPlayer() != PlayerNumberType.PLAYER_TWO)){
	            					p2.incrementScore();
	            				}
	            				else if((gameBall.getLastHitBy()==PlayerNumberType.PLAYER_THREE)&&
										(gameBoard.getAt(x,y).getPlayer() != PlayerNumberType.PLAYER_THREE)){
	            					p3.incrementScore();
	            				}
	            				else if((gameBall.getLastHitBy()==PlayerNumberType.PLAYER_FOUR)&&
										(gameBoard.getAt(x,y).getPlayer() != PlayerNumberType.PLAYER_FOUR)){
	            					p4.incrementScore();
	            				}
	            			}	       
	            			break outerloop;
	            	}
	            }
	        	//if the balls colliding with a paddle 
	    		else if((gameBoard.getAt(x,y) != null) && (gameBoard.getAt(x,y).isAlive()) 
	    				&& ((gameBoard.getAt(x,y).getObjectType() == ObjectType.PADDLE))){
	    			if((sprite.getBoundary(gameBall).intersects(sprite.getBoundary(gameBoard.getAt(x, y))))){
						gameControl.countDownSound.play();
						//set last hit by to this player 
	    				gameBall.setLastHitBy((gameBoard.getAt(x, y).getPlayer()));
	    				//reflect the ball appropriately 
	    				if(gameBoard.getAt(x, y).getPlayer()==PlayerNumberType.PLAYER_ONE){
	    					gameBall.paddleReflect(p1.getPlayersPaddle());
	    				}
	    				else if(gameBoard.getAt(x, y).getPlayer()==PlayerNumberType.PLAYER_TWO){
	    					gameBall.paddleReflect(p2.getPlayersPaddle());
	    				}
	    				else if(gameBoard.getAt(x, y).getPlayer()==PlayerNumberType.PLAYER_THREE){
	    					gameBall.paddleReflect(p3.getPlayersPaddle());
	    				}
	    				else if(gameBoard.getAt(x, y).getPlayer()==PlayerNumberType.PLAYER_FOUR){
	    					gameBall.paddleReflect(p4.getPlayersPaddle());
	    				}
	    				break outerloop;
	    			}
	    		}
	        	//if the ball hits a powerup
	    		else if((gameBoard.getAt(x,y) != null) && (gameBoard.getAt(x,y).isAlive())
	    				&& ((gameBoard.getAt(x,y).getObjectType() == ObjectType.POWERUP))){
	    			if((sprite.getBoundary(gameBall).intersects(sprite.getBoundary(gameBoard.getAt(x, y))))){
	    				//if the ball has been hit by a player
	    				if(gameBall.getLastHitBy()!=null){
	    					//set the powerup to dead 
	    					if(gameBoard.getAt(x, y).getObjectType()!=ObjectType.BALL){
	            				gameBoard.getAt(x, y).setDead();
	            			}
	    				gameControl.powerUpSound.play();
	    				//perform the powerup
	    				powerUp.setPower();
	    				break outerloop;
	    				}
	    			}
	    		}
	        	//if the ball hits a player
	    		else if((gameBoard.getAt(x,y) != null) && (gameBoard.getAt(x,y).isAlive())
	    				&& ((gameBoard.getAt(x,y).getObjectType() == ObjectType.PLAYER))){
	    			if((sprite.getBoundary(gameBall).intersects(sprite.getBoundary(gameBoard.getAt(x, y))))){
	    				//reflect the ball appropriately 
            			gameBall.objectReflect(gameBoard.getAt(x, y));
            			//kill the player
	    				gameBoard.getAt(x, y).setDead();
						gameControl.setPlayerWallsToZero(gameBoard.getAt(x, y).getPlayer());
						for (int j = 0; j <1024; j++){
							for (int k = 0; k < 768; k++) {
								if(gameBoard.getAt(j, k)!=null){
									if(gameBoard.getAt(j, k).getPlayer()==gameBoard.getAt(x, y).getPlayer()){
										gameControl.playerDeath.play(0.25);
										gameBoard.getAt(j, k).setDead();
	    			        		}
	    			        	}
	    			        }
	    				}
	    				break outerloop;		
	    			}
	    		}
	        	//if the game ball doesn't collide with anything
	    		else if((gameBall.getXPos()+gameBall.getXVelocity())>0 && (gameBall.getYPos()+gameBall.getYVelocity())>0){
	    	    	pass = true;
	    	    }
	        }
		
		}

		if(negativeReflect){
			gameBall.negativeBoundaryReflect(0, 0);
			negativeReflect = false;
		}
		else if(positiveReflect){
			gameBall.positiveBoundaryReflect((1024-gameBall.getWidth()), (768-gameBall.getHeight()));
			positiveReflect = false;
		}
		else if(pass){
			gameBall.pass();
			pass = false;
		}

		// If ball is stuck
        if (ballIsStuck()) {
			timesStuck++;
		} else {
			timesStuck = 0;
        }
		if (timesStuck == 10) {
			unStuckTheBall();
			timesStuck = 0;
		}
	}

    // Helper function to determine if ball is stuck
    private boolean ballIsStuck() {
        int ballXPos = this.gameBall.getXPos();
        int ballYPos = this.gameBall.getYPos();

        if ((ballYPos <= 15) || (ballYPos >= gameBoard.getyMax()-15) || (ballXPos <= 15) || (ballXPos >= gameBoard.getxMax()-15)) {
            return true;
        } else {
            return false;
        }
    }

    // Method that moves the ball out of the spot where it is getting smushed between the paddle and game boundaries.
    private void unStuckTheBall() {
        int ballXPos = this.gameBall.getXPos();
        int ballYPos = this.gameBall.getYPos();
        int positionCorrection = 35;

        if (ballYPos <= 10) {
			// Move ball left or right to fix

			// Determine direction to move ball (in x plane)
			if (ballXPos+positionCorrection < gameBoard.getxMax()-positionCorrection) {

				// Move the ball right
				this.gameBall.setXPos(ballXPos+positionCorrection);

			} else {

				// Move the ball left
                this.gameBall.setXPos(ballXPos-positionCorrection);

            }

            this.gameBall.setYPos(ballYPos+positionCorrection);

		} else if (ballYPos >= gameBoard.getyMax()-10) {
            // Move ball left or right to fix

            // Determine direction to move ball (in x plane)
            if (ballXPos+positionCorrection < gameBoard.getxMax()-positionCorrection) {

                // Move the ball right
                this.gameBall.setXPos(ballXPos+positionCorrection);

            } else {

                // Move the ball left
                this.gameBall.setXPos(ballXPos-positionCorrection);

            }

            this.gameBall.setYPos(ballYPos-positionCorrection);

        } else if (ballXPos <= 10) {
			// Move ball up or down to fix.

			// Determine direction to move the ball (in y plane)
			if (ballYPos+positionCorrection < gameBoard.getyMax()-positionCorrection) {

				// Moving the ball down is okay
				this.gameBall.setYPos(ballYPos+positionCorrection);

			} else {

				// Move the ball up
				this.gameBall.setYPos(ballYPos-positionCorrection);

			}

            this.gameBall.setXPos(ballXPos+positionCorrection);

		} else if (ballXPos >= gameBoard.getxMax()-10) {
            // Move ball up or down to fix.

            // Determine direction to move the ball (in y plane)
            if (ballYPos+positionCorrection < gameBoard.getyMax()-positionCorrection) {

                // Moving the ball down is okay
                this.gameBall.setYPos(ballYPos+positionCorrection);

            } else {

                // Move the ball up
                this.gameBall.setYPos(ballYPos-positionCorrection);

            }

            this.gameBall.setXPos(ballXPos-positionCorrection);

        }

    }
}


