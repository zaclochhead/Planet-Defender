package control;

import javafx.scene.image.Image;
import javafx.scene.media.AudioClip;
import model.*;
import java.io.File;
import java.util.ArrayList;

/**
 *  The GameControl class creates a new game and controls all of the game logic.
 */
public class GameControl implements warlordstest.IGame {

	private Ball gameBall;
	private PlayerAvatar player1,player2,player3,player4;
	private BallControl ballcontrol;
    private int timeRemaining;
    private boolean finished;
    private PowerUp powerUp;
    public GameBoard gameBoard;
    private Paddle paddle1;
    private PaddleControl pControl1, pControl2, pControl3, pControl4;
    private Boolean isPaused;
    private PlayerAvatar winner;
    private LevelType level;
    private Wall wall1, wall2, wall3, wall4;
    private Paddle paddle2, paddle3, paddle4;

    private int difficulty;

    // Sound declaration. Final 3 are declared with no modifier as they are package private
    public AudioClip countDownSound = new AudioClip(new File("countDownSound.wav").toURI().toString());;
    AudioClip playerDeath = new AudioClip(new File("playerDeath.wav").toURI().toString());
    AudioClip wallDeath = new AudioClip(new File("wallDeath.wav").toURI().toString());
    AudioClip powerUpSound = new AudioClip(new File("powerUp.wav").toURI().toString());

    // Game constructor sets up game parameters and calls newGame to prepare new game objects
    // Human player count determines number of non-AI players.
    // Difficulty alters the initial ball speed, and AI difficulty
    // Level determines sprites and number of wall layers to give players 2, 3 and 4.
    public GameControl(int humanPlayerCount, int difficulty, LevelType level){
        setTimeRemaining(120);
        setFinished(false);
        setPaused(false);
        setDifficulty(difficulty);
        setLevel(level);
        newGame(1024,768, humanPlayerCount);
    }

    public void setLevel(LevelType level) {
        this.level = level;
    }

    public LevelType getLevel() {
        return level;
    }

    public void setWinner(PlayerAvatar winner) {
        this.winner = winner;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public Boolean getIsPaused() {
        return isPaused;
    }

    // Stores logically if the game is paused. Does not pause tick.
    public void setPaused(Boolean paused) {
        isPaused = paused;
    }

    private void newGame(int width, int height, int humanPlayers) {


        // Declaration of variable to hold number of layers to remove from the default of 3
        // this is determined by the difficulty.
        int layersToRemove;

        // If true, AI is enabled for respective player.
        boolean player1AI,player2AI,player3AI,player4AI;

        // Determine which players should be controlled by AI
        switch (humanPlayers) {
            case 0 :
                player1AI = true;
                player2AI = true;
                player3AI = true;
                player4AI = true;
                break;
            case 1 :
                player1AI = false;
                player2AI = true;
                player3AI = true;
                player4AI = true;
                break;
            case 2 :
                player1AI = false;
                player2AI = false;
                player3AI = true;
                player4AI = true;
                break;
            case 3 :
                player1AI = false;
                player2AI = false;
                player3AI = false;
                player4AI = true;
                break;
            case 4 :
                player1AI = false;
                player2AI = false;
                player3AI = false;
                player4AI = false;
                break;
            default :
                player1AI = true;
                player2AI = true;
                player3AI = true;
                player4AI = true;
        }

        // Setup empty game board (to store all game objects logically)
        gameBoard = new GameBoard(width, height);

        // Setup player 1 paddle and controller then add the paddle to the gameboard
        paddle1 = new Paddle(PlayerNumberType.PLAYER_ONE);
        paddle1.setObjectType(ObjectType.PADDLE);
        pControl1 = new PaddleControl(paddle1,gameBoard.getxMax(), gameBoard.getyMax(), player1AI);
        pControl1.setmaxVelocity(10);
        gameBoard.addObject(paddle1);

        // Setup player 2 paddle and controller then add the paddle to the gameboard
        paddle2 = new Paddle(PlayerNumberType.PLAYER_TWO);
        paddle2.setObjectType(ObjectType.PADDLE);
        pControl2 = new PaddleControl(paddle2,gameBoard.getxMax(), gameBoard.getyMax(), player2AI);
        pControl2.setmaxVelocity(10);
        gameBoard.addObject(paddle2);

        // Setup player 3 paddle and controller then add the paddle to the gameboard
        paddle3 = new Paddle(PlayerNumberType.PLAYER_THREE);
        paddle3.setObjectType(ObjectType.PADDLE);
        pControl3 = new PaddleControl(paddle3,gameBoard.getxMax(), gameBoard.getyMax(), player3AI);
        pControl3.setmaxVelocity(10);
        gameBoard.addObject(paddle3);

        // Setup player 4 paddle and controller then add the paddle to the gameboard
        paddle4 = new Paddle(PlayerNumberType.PLAYER_FOUR);
        paddle4.setObjectType(ObjectType.PADDLE);
        pControl4 = new PaddleControl(paddle4,gameBoard.getxMax(), gameBoard.getyMax(), player4AI);
        pControl4.setmaxVelocity(10);
        gameBoard.addObject(paddle4);

        // Create new ball. Uses difficulty to help determine initial velocity.
        gameBall = new Ball(difficulty);

        // Add new ball to game board
        gameBoard.addObject(gameBall);

        // Setup player 2 avatar and add it to game board
        player2 = new PlayerAvatar(PlayerNumberType.PLAYER_TWO,paddle2);
        gameBoard.addObject(player2);
        player2.setObjectType(ObjectType.PLAYER);

        // Setup player 3 avatar and add it to game board
        player3 = new PlayerAvatar(PlayerNumberType.PLAYER_THREE,paddle3);
        gameBoard.addObject(player3);
        player3.setObjectType(ObjectType.PLAYER);

        // Setup player 4 avatar and add it to game board
        player4 = new PlayerAvatar(PlayerNumberType.PLAYER_FOUR,paddle4);
        gameBoard.addObject(player4);
        player4.setObjectType(ObjectType.PLAYER);

        // Setup player 1 avatar and add it to game board
        player1 = new PlayerAvatar(PlayerNumberType.PLAYER_ONE,paddle1);
        gameBoard.addObject(player1);
        player1.setObjectType(ObjectType.PLAYER);

        // Add player 1 walls
        for (int y = 0; y < 215; y += 30) {
            for (int x = 0; x < 215; x +=30) {
                if ((x > 135) || (y > 135)) {
                	wall1 = new Wall(PlayerNumberType.PLAYER_ONE, x, y);
                	wall1.setObjectType(ObjectType.WALL);
                    gameBoard.addObject(wall1);
                    player1.setWallsRemaining(player1.getWallsRemaining()+1);
                }
            }
        }

        // Determine number of AI walls to remove from default of 3
        if (difficulty == 1) {
            layersToRemove = 2;
        } else if (difficulty == 2) {
            layersToRemove = 1;
        } else {
            layersToRemove = 0;
        }

        // Add player 2 walls
        for (int y = 0; y <= (215-(layersToRemove * 30)); y += 30) {
            for (int x = width-30; x >= width-245+(layersToRemove * 30); x -= 30) {
                if (((x < width-165)) || (y > 135)) {
                	wall2 = new Wall(PlayerNumberType.PLAYER_TWO, x, y);
                	wall2.setObjectType(ObjectType.WALL);
                    gameBoard.addObject(wall2);
                    player2.setWallsRemaining(player2.getWallsRemaining()+1);

                }
            }
        }

        // Add player 3 walls
        for (int y = height-30; y >= height-245+(layersToRemove * 30); y -= 30) {
            for (int x = 0; x <= 215-(layersToRemove * 30); x += 30) {
                if (((x > 135)) || (y < (height-165))) {
                	wall3 = new Wall(PlayerNumberType.PLAYER_THREE, x, y);
                	wall3.setObjectType(ObjectType.WALL);
                    gameBoard.addObject(wall3);
                    player3.setWallsRemaining(player3.getWallsRemaining()+1);

                }
            }
        }

        // Add player 4 walls
        for (int y = height-30; y >= height-245+(layersToRemove * 30); y -= 30) {
            for (int x = width-30; x >= width-245+(layersToRemove * 30); x -= 30) {
                if (((x < width-165)) || (y < (height-165))) {
                	wall4 = new Wall(PlayerNumberType.PLAYER_FOUR, x, y);
                	wall4.setObjectType(ObjectType.WALL);
                    gameBoard.addObject(wall4);
                    player4.setWallsRemaining(player4.getWallsRemaining()+1);

                }
            }
        }

        // Determine graphics to display based on level
        switch (level) {
            case DEMO:
                player1.setSprite(new Image("images/earth.png"));
                player2.setSprite(new Image("images/mars.png"));
                player3.setSprite(new Image("images/moon.png"));
                player4.setSprite(new Image("images/alien1.png"));
                break;
            case ONE_MARS:
                player1.setSprite(new Image("images/mars.png"));
                player2.setSprite(new Image("images/alien1.png"));
                player3.setSprite(new Image("images/alien2.png"));
                player4.setSprite(new Image("images/alien3.png"));
                break;
            case TWO_MOON:
                player1.setSprite(new Image("images/moon.png"));
                player2.setSprite(new Image("images/alien1.png"));
                player3.setSprite(new Image("images/alien2.png"));
                player4.setSprite(new Image("images/alien3.png"));
                break;
            case THREE_EARTH:
                player1.setSprite(new Image("images/earth.png"));
                player2.setSprite(new Image("images/alien1.png"));
                player3.setSprite(new Image("images/alien2.png"));
                player4.setSprite(new Image("images/alien3.png"));
                break;
        }

        // Setup ball control to manage the ball.
        ballcontrol = new control.BallControl(gameBall, gameBoard, player1, player2,
                player3, player4, this);
    }

    // GameBall getter
    public Ball getBall(){
    	return gameBall;
    }

    // Paddle getter
    public Paddle getPaddle(){
    	return paddle1;
    }

    // Player 1 getter
    public PlayerAvatar getPlayer1(){
    	return player1;
    }

    // Player 2 getter
    public PlayerAvatar getPlayer2(){
    	return player2;
    }
    
    // Player 3 getter
    public PlayerAvatar getPlayer3(){
    	return player3;
    }

    // Player 4 getter
    public PlayerAvatar getPlayer4(){
    	return player4;
    }

    // Helper function that decreases (by 1) the logical number of walls a player has remaining.
    // Does not remove walls from the game board.
    public void decrementPlayerWalls(PlayerNumberType player) {
        switch (player) {
            case PLAYER_ONE:
                player1.setWallsRemaining(player1.getWallsRemaining()-1);
                break;
            case PLAYER_TWO:
                player2.setWallsRemaining(player2.getWallsRemaining()-1);
                break;
            case PLAYER_THREE:
                player3.setWallsRemaining(player3.getWallsRemaining()-1);
                break;
            case PLAYER_FOUR:
                player4.setWallsRemaining(player4.getWallsRemaining()-1);
                break;
        }
    }

    // Helper function that sets the logical number of walls a player has to zero. (ie when a player
    // is killed) Does not remove walls from the game board.
    public void setPlayerWallsToZero(PlayerNumberType player) {
        switch (player) {
            case PLAYER_ONE:
                player1.setWallsRemaining(0);
                break;
            case PLAYER_TWO:
                player2.setWallsRemaining(0);
                break;
            case PLAYER_THREE:
                player3.setWallsRemaining(0);
                break;
            case PLAYER_FOUR:
                player4.setWallsRemaining(0);
                break;
        }
    }

    // Time remaining setter
    public void setTimeRemaining(int timeRemaining) {
        this.timeRemaining = timeRemaining;
    }

    // Time remaining getter
    public int getTimeRemaining() {
        return timeRemaining;
    }

    // Returns the game winner
    public PlayerAvatar getWinner() {
        return this.winner;
    }

    // Returns the game winner as a string
    public String getWinnerAsString() {
        if (getWinner() == player1) {
            return "Player 1";
        } else if (getWinner() == player2) {
            return "Player 2";
        } else if (getWinner() == player3) {
            return "Player 3";
        } else {
            // Player 4 is the winner
            return "Player 4";
        }
    }
    
    // Handles one tick of the game.
    // This means all moving objects must be moved.
    public void tick(){
        pControl1.move();
        pControl2.move();
        pControl3.move();
        pControl4.move();
        
        Sprite sprite;
        sprite = new Sprite();
      //spawns a powerup at a random position if theres not one in the game 
    	if((powerUp == null)|| (powerUp.isDead())){
		    	powerUp = new PowerUp(gameBall,player1,player2,player3,player4,
		    	pControl1, pControl2,pControl3,pControl4,wall1,wall2,wall3,wall4,
		    	gameBoard,difficulty);
		    	powerUp.setObjectType(ObjectType.POWERUP);
		    	ballcontrol.addPowerUp(powerUp);
		    //if the powerups not trying to spawn at the same place as the ball 
			if((sprite.getBoundary(powerUp).intersects(sprite.getBoundary(gameBall)))){
				System.out.print(1);
				powerUp.setDead();
			}		
			else
			{
				gameBoard.addObject(powerUp);
			}
    	}

        ballcontrol.move();
    }

    // Checks if the game is finished or not, sets finished variable, and returns it.
    // There are two conditions in which the game is finished; all but one player is dead,
    // or game time is zero.
    public boolean isFinished() {
        if (getTimeRemaining() == 0) {

            // If no time remaining the game is finished.
            // The winner is the one with the most walls remaining,
            // or the highest score if wall count results in draw (ie null return).

            setFinished(true);

            if (findMostWallsRemaining() == null) {

                // One or more players have the same number of walls remaining
                // Use score to set winning player.
                findHighestScore().setWinner(true);
                this.setWinner(findHighestScore());
                return true;

            } else {

                // Set player with most walls remaining as the winner
                findMostWallsRemaining().setWinner(true);
                this.setWinner(findMostWallsRemaining());
                return true;
            }

        } else if (numberOfDeadPlayers() >= 3){

            // Three or more players dead, hence game finished,
            // and alive player is winner.

            setFinished(true);

            // Determine which player is alive (as all walls are set to zero when a player dies
            // we can use this to determine who is alive)
            if (player1.getWallsRemaining() != 0) {
                player1.setWinner(true);
                this.setWinner(player1);
            } else if (player2.getWallsRemaining() != 0) {
                player2.setWinner(true);
                this.setWinner(player2);
            } else if (player3.getWallsRemaining() != 0) {
                player3.setWinner(true);
                this.setWinner(player3);
            } else if (player4.getWallsRemaining() != 0) {
                player4.setWinner(true);
                this.setWinner(player4);
            }
            return true;
        } else {

            // Game not finished.
            return false;

        }

    }

    // Helper function for isFinished method. Returns number of dead players.
    private int numberOfDeadPlayers() {
        int countOfDead = 0;
        if (player1.isDead()) {
            countOfDead++;
        }
        if (player2.isDead()) {
            countOfDead++;
        }
        if (player3.isDead()){
            countOfDead++;
        }
        if (player4.isDead()){
            countOfDead++;
        }
        return countOfDead;
    }

    // Helper function for isFinished method. Returns player with most walls remaining.
    private PlayerAvatar findMostWallsRemaining() {
        if ((player1.getWallsRemaining() >= player2.getWallsRemaining()) &&
                (player1.getWallsRemaining() >= player3.getWallsRemaining()) &&
                (player1.getWallsRemaining() >= player4.getWallsRemaining())){
            return player1;
        } else if ((player2.getWallsRemaining() >= player1.getWallsRemaining()) &&
                (player2.getWallsRemaining() >= player3.getWallsRemaining()) &&
                (player2.getWallsRemaining() >= player4.getWallsRemaining())) {
            return player2;
        } else if ((player3.getWallsRemaining() >= player1.getWallsRemaining()) &&
                (player3.getWallsRemaining() >= player2.getWallsRemaining()) &&
                (player3.getWallsRemaining() >= player4.getWallsRemaining())) {
            return  player3;
        } else if ((player4.getWallsRemaining() >= player1.getWallsRemaining()) &&
                (player4.getWallsRemaining() >= player2.getWallsRemaining()) &&
                (player4.getWallsRemaining() >= player3.getWallsRemaining())) {
            return player4;
        } else {
            return null;
        }
    }
    
    // Helper function for isFinished method. Returns highest scoring payer, or null to indicate
    // draw.
    private PlayerAvatar findHighestScore() {
        if ((player1.getScore() > player2.getScore()) &&
                (player1.getScore() > player3.getScore()) &&
                (player1.getScore() > player4.getScore())){
            return player1;
        } else if ((player2.getScore() > player1.getScore()) &&
                (player2.getScore() > player3.getScore()) &&
                (player2.getScore() > player4.getScore())) {
            return player2;
        } else if ((player3.getScore() > player1.getScore()) &&
                (player3.getScore() > player2.getScore()) &&
                (player3.getScore() > player4.getScore())) {
            return  player3;
        } else if ((player4.getScore() > player1.getScore()) &&
                (player4.getScore() > player2.getScore()) &&
                (player4.getScore() > player3.getScore())) {
            return player4;
        } else {
            // Player wins if draw. (Prevents draw conditions)
            return player1;
        }
    }
    
    // Sets the game as finished. Note does not determine if finished.
    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    // Handle user input. Determine if paddle is AI/Human and then consider current inputs.
    public void handleInput(ArrayList<String> input) {

        // If paddle is not computer controlled
        if (!pControl1.isAI()) {
            // Accelerate paddle based on user input (Keys; x and z)
            if (input.contains("X")) {
                this.pControl1.accelerate(2);
            } else if (input.contains("Z")) {
                this.pControl1.accelerate(-2);
            }
        } else {
            pControl1.AIMove(gameBall.getXPos(), gameBall.getYPos(), difficulty);
        }

        // Repeat for remaining 3 paddles

        if (!pControl2.isAI()) {
            // Accelerate paddle based on user input (Keys; left and right)
            if (input.contains("V")) {
                this.pControl2.accelerate(-2);
            } else if (input.contains("B")) {
                this.pControl2.accelerate(2);
            }
        } else {
            pControl2.AIMove(gameBall.getXPos(),gameBall.getYPos(), difficulty);
        }

        if (!pControl3.isAI()) {
            // Accelerate paddle based on user input (Keys; V and B)
            if (input.contains("COMMA")) {
                this.pControl3.accelerate(-2);
            } else if (input.contains("PERIOD")) {
                this.pControl3.accelerate(2);
            }
        } else {
            pControl3.AIMove(gameBall.getXPos(),gameBall.getYPos(), difficulty);
        }

        if (!pControl4.isAI()) {
            // Accelerate paddle based on user input (Keys; M and N)
            if (input.contains("RIGHT")) {
                this.pControl4.accelerate(2);
            } else if (input.contains("LEFT")) {
                this.pControl4.accelerate(-2);
            }
        } else {
            pControl4.AIMove(gameBall.getXPos(),gameBall.getYPos(), difficulty);
        }
    }
    
}