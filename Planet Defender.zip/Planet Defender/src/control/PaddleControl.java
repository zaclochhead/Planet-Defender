package control;

import model.Paddle;
import model.PlayerNumberType;

import static java.lang.Math.abs;

/**
 * Paddle control manages a paddle object instance.
 *
 * This includes managing acceleration, movement and friction.
 * Movement manages collisions with the game boundaries.
 */
public class PaddleControl {

    // Paddle stores the paddle instance the paddle control instance controls
    private Paddle paddle;

    // Stores the maximum boundaries of the game (used in boundary collisions)
    private int xMax, yMax;

    // Boolean to represent if the paddle is traveling in the x plane or y plane
    // (as it can only do one at a time)
    private boolean xPlaneTravel;

    // X and Y position that manages paddle path changes from X plane to Y plane
    // (and vice versa)
    private int xSwapPos, ySwapPos;

    // Boolean to hold if the paddle instance is controlled by AI or human
    private boolean isAI;
    //the maximum velocity that the paddle can reach 
    private int maxVelocity;
    // Constructor requires paddle to be controlled, game boundaries and if the paddle
    // is to be AI controlled or not.
    public PaddleControl(Paddle paddle, int xMax, int yMax, boolean isAI) {
        this.paddle = paddle;
        this.xMax = xMax;
        this.yMax = yMax;
        this.isAI = isAI;

        // Define swap positions, initial positions and initial plane of travel based on
        // the paddle's controlling player
        switch (paddle.getPlayer()) {
            case PLAYER_ONE:
                xSwapPos = 275;
                ySwapPos = 275;
                paddle.setXPos(xSwapPos-1);
                xPlaneTravel = true;
                paddle.setYPos(ySwapPos);
                break;
            case PLAYER_TWO:
                xSwapPos = 1024-275-35;
                ySwapPos = 275;
                paddle.setXPos(xSwapPos-1);
                xPlaneTravel = true;
                paddle.setYPos(ySwapPos);
                break;
            case PLAYER_THREE:
                xSwapPos = 275;
                ySwapPos = 768-275-35;
                paddle.setXPos(xSwapPos-1);
                xPlaneTravel = true;
                paddle.setYPos(ySwapPos);
                break;
            case PLAYER_FOUR:
                xSwapPos = 1024-275-35;
                ySwapPos = 768-275-35;
                paddle.setXPos(xSwapPos);
                xPlaneTravel = false;
                paddle.setYPos(ySwapPos+5);
                break;
        }

    }
    //set the maximum velocity the paddle can reach 
    public void setmaxVelocity(int maxVelocity){
    	this.maxVelocity = maxVelocity;
    }
    //get the maximum velocity that the paddle can reach 
    public int getmaxVelocity(){
    	return this.maxVelocity;
    }
    // Accelerates the controlled paddle in the amount passed to a maximum specified.
    public void accelerate(int acceleration) {
        int xVel = paddle.getXVelocity();
        int yVel = paddle.getYVelocity();
        PlayerNumberType player = paddle.getPlayer();

        // As player one and four travel in "reverse" to player three and two
        if (((player == PlayerNumberType.PLAYER_FOUR) && (!xPlaneTravel) ) ||
                ((player  == PlayerNumberType.PLAYER_ONE) && (!xPlaneTravel))) {
            // reverse acceleration
            acceleration = -acceleration;
        }

        // Determine if x or y direction acceleration
        if (xPlaneTravel) {

            // Check if maximum velocity would be reached to determine new velocity.
            // and if so, set velocity to just below maximum.
            if ((xVel > 0) && (xVel + acceleration > maxVelocity)) {
                paddle.setXVelocity(maxVelocity - 1);
            } else if ((xVel < 0) && (abs(xVel) + abs(acceleration) > maxVelocity)) {
                paddle.setXVelocity(-maxVelocity + 1);
            } else {
                // otherwise, increase by acceleration
                paddle.setXVelocity(xVel + acceleration);
            }
        } else {

            // Repeat for y velocity
            if ((yVel > 0) && (yVel + acceleration > maxVelocity)) {
                paddle.setYVelocity(maxVelocity - 1);
            } else if ((yVel < 0) && (abs(yVel) + abs(acceleration) > maxVelocity)) {
                paddle.setYVelocity(-maxVelocity + 1);
            } else {
                paddle.setYVelocity(yVel + acceleration);
            }
        }
    }

    // Manages paddle movement based on paddle velocity
    // Handles paddle collisions with game boundary
    public void move() {
        int xPos, xVel, yPos, yVel, xFinalPos, yFinalPos, distanceToBoundary;
        PlayerNumberType player;

        // Get velocity, position
        xPos = paddle.getXPos();
        xVel = paddle.getXVelocity();
        yPos = paddle.getYPos();
        yVel = paddle.getYVelocity();

        // Get paddle player
        player = paddle.getPlayer();

        // Projected final positions (assuming no collisions)
        xFinalPos = xPos + xVel;
        yFinalPos = yPos + yVel;

        // Determine if game boundary/path boundary collision
        // Note: All paddle collisions are assumed to be with ONLY x or y velocity.
        if (xFinalPos < 0) {
            // Left wall collision

            paddle.setXVelocity(xVel * -1);
            distanceToBoundary = xPos;
            xFinalPos = abs(xVel) - distanceToBoundary;
            paddle.setXPos(xFinalPos);

        } else if (xFinalPos >= (xMax - paddle.getWidth())) {
            // Right wall collision

            paddle.setXVelocity(xVel * -1);
            distanceToBoundary = xMax - paddle.getWidth() - xPos;
            xFinalPos = xMax - paddle.getWidth() - (abs(xVel) - distanceToBoundary);
            paddle.setXPos(xFinalPos);

        } else if (yFinalPos < 0) {
            // TOP wall collision

            paddle.setYVelocity(yVel * -1);
            distanceToBoundary = yPos;
            yFinalPos = abs(yVel) - distanceToBoundary;
            paddle.setYPos(yFinalPos);

        } else if (yFinalPos > (yMax-paddle.getHeight())){
            // BOTTOM wall collision

            paddle.setYVelocity(yVel * -1);
            distanceToBoundary = yMax - paddle.getHeight() - yPos;
            yFinalPos = yMax - paddle.getHeight() - (abs(yVel) - distanceToBoundary);
            paddle.setYPos(yFinalPos);
        } else if (((xFinalPos >= xSwapPos) && (xPlaneTravel) && ((player == PlayerNumberType.PLAYER_THREE)||(player == PlayerNumberType.PLAYER_ONE))) ||
                ((xFinalPos <= xSwapPos) && (xPlaneTravel) && ((player == PlayerNumberType.PLAYER_TWO)||(player == PlayerNumberType.PLAYER_FOUR))))
        {
            // Swap boundary collision (ie the paddle is at the meeting point between its vertical (y) path
            // and horizontal (x) path

            // Swap plane of travel from X to Y
            xPlaneTravel = false;

            // Convert x velocity into y velocity (negating when p1 or p4)
            if ((player == PlayerNumberType.PLAYER_ONE) || (player == PlayerNumberType.PLAYER_FOUR)) {
                // Player 1 or 4
                // Y velocity becomes the negative of x velocity
                paddle.setYVelocity(-xVel);
            } else {
                // Player 2 or 3
                // Y velocity becomes x velocity
                paddle.setYVelocity(xVel);
            }

            // and x velocity is set to zero
            paddle.setXVelocity(0);

        } else if (((yFinalPos >= ySwapPos) && (!xPlaneTravel) && ((player == PlayerNumberType.PLAYER_TWO)||(player == PlayerNumberType.PLAYER_ONE))) ||
                ((yFinalPos <= ySwapPos) && (!xPlaneTravel) && ((player == PlayerNumberType.PLAYER_THREE)||(player == PlayerNumberType.PLAYER_FOUR))))
        {
            // Swap boundary collision (ie the paddle is at the meeting point between its vertical (y) path
            // and horizontal (x) path

            // Swap plane of travel from Y to X
            xPlaneTravel = true;

            // Update sprite to X plane sprite.
            this.paddle.setSprite(this.paddle.spriteX);

            // Convert y velocity into x velocity (negating when p1 or p4)
            if ((player == PlayerNumberType.PLAYER_ONE) || (player == PlayerNumberType.PLAYER_FOUR)) {
                // X velocity becomes the negative of Y velocity
                paddle.setXVelocity(-yVel);
            } else {
                // X velocity becomes Y velocity
                paddle.setXVelocity(yVel);
            }

            // and y velocity becomes zero
            paddle.setYVelocity(0);

        } else {

            // No collision update position
            paddle.setXPos(xPos + xVel);
            paddle.setYPos(yPos + yVel);

        }

        // Updating sprite while in the Y plane of travel
        // As AI bounces around swap position, doing it when
        // slightly in y plane of travel will prevent image flickering.
        if ((!xPlaneTravel) && (abs(paddle.getYPos()-ySwapPos) > 10)) {
            this.paddle.setSprite(this.paddle.spriteY);
        }

        // Add in friction physics.
        this.friction(1);
    }

    // Implementation of deceleration due to friction
    public void friction(int multiplier) {
        this.decelerate(multiplier, xPlaneTravel);
    }

    // Helper function to decelerate the paddle based on its direction of travel (x or y)
    // and an amount decrease by. Reduces absolute velocity, ie sets velocity closer to zero.
    private void decelerate(int amount, boolean xDirectionDeceleration) {
        if (xDirectionDeceleration) {
            if (paddle.getXVelocity() > 0) {
                paddle.setXVelocity(paddle.getXVelocity()-amount);
            } else if (paddle.getXVelocity() < 0) {
                paddle.setXVelocity(paddle.getXVelocity()+amount);
            }
        } else {
            if (paddle.getYVelocity() > 0) {
                paddle.setYVelocity(paddle.getYVelocity()-amount);
            } else if (paddle.getYVelocity() < 0){
                paddle.setYVelocity(paddle.getYVelocity()+amount);

            }
        }
    }

    // Set paddle as dead.
    public void setDead() {
        this.paddle.setDead();
    }

    // Return is the paddle is controlled by AI
    public boolean isAI() {
        return isAI;
    }

    // Set paddle as AI/Human controlled
    public void setAI(boolean AI) {
        this.isAI = AI;
    }

    // Run AI to determine and enact AI's movement for this turn
    public void AIMove(int ballXPos, int ballYPos, int difficulty) {

        // Add in random roll to skip AI move. These chances decrease as difficulty increases.
        switch (this.paddle.getPlayer()) {
            case PLAYER_ONE:
                // Baseline 60% chance of skip,
                if (Math.random() <= 0.60/difficulty) {
                    return;
                }
                break;
            case PLAYER_TWO:
                // Baseline 35% chance of skip
                if (Math.random() <= 0.35/difficulty) {
                    return;
                }
                break;
            case PLAYER_THREE:
                // Baseline 50% chance of skip
                if (Math.random() <= 0.5/difficulty) {
                    return;
                }
                break;
            case PLAYER_FOUR:
                // Baseline 20% chance of skip
                if (Math.random() <= 0.4/difficulty) {
                    return;
                }
                break;
        }

        // Centered x and y positions
        int paddleXPos = this.paddle.getXPos() + (this.paddle.getWidth() / 2);
        int paddleYPos = this.paddle.getYPos() + (this.paddle.getHeight() / 2);

        // The paddle will always head toward the ball based on its x and y position
        if ((this.paddle.getPlayer() == PlayerNumberType.PLAYER_THREE) ||
        (this.paddle.getPlayer() == PlayerNumberType.PLAYER_TWO)){

            // Offset paddle position (to add in variance between AIs)
            paddleXPos += 10/difficulty;

            if ((ballYPos < paddleYPos) && (!xPlaneTravel)) {
                // Ball lower than paddle,
                // hence move paddle down
                accelerate(-2);

            } else if ((ballYPos > paddleYPos) && (!xPlaneTravel)) {
                // Ball higher than paddle,
                // hence move paddle up
                accelerate(2);

            } else if ((ballXPos < paddleXPos) && (xPlaneTravel)) {
                // Ball left of paddle,
                // hence move paddle left
                accelerate(-2);

            } else if ((ballXPos > paddleXPos) && (xPlaneTravel)) {
                // Ball right of paddle,
                // hence move paddle right
                accelerate(2);
            }
        }

        if ((this.paddle.getPlayer() == PlayerNumberType.PLAYER_ONE) ||
        (this.paddle.getPlayer() == PlayerNumberType.PLAYER_FOUR)) {
            if ((ballYPos > paddleYPos) && (!xPlaneTravel)) {
                // Ball lower than paddle,
                // hence move paddle down
                accelerate(-2);

            } else if ((ballYPos < paddleYPos) && (!xPlaneTravel)) {
                // Ball higher than paddle,
                // hence move paddle up
                accelerate(2);

            } else if ((ballXPos < paddleXPos) && (xPlaneTravel)) {
                // Ball left of paddle,
                // hence move paddle left
                accelerate(-2);

            } else if ((ballXPos > paddleXPos) && (xPlaneTravel)) {
                // Ball right of paddle,
                // hence move paddle right
                accelerate(2);
            }

        }

    }

}
