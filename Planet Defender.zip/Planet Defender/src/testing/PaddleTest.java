
package testing;

import model.Paddle;
import model.PlayerNumberType;
import org.junit.Test;

import static org.junit.Assert.*;

public class PaddleTest {
    Paddle paddle = new Paddle(PlayerNumberType.PLAYER_ONE);

    @Test
    public void test(){
    }

}