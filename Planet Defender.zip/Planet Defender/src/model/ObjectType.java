package model;

//enum of all the object types 
public enum ObjectType {
	PLAYER,PADDLE,WALL,POWERUP,BALL;
}
