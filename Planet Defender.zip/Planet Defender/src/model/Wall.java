package model;

import javafx.scene.image.Image;

/**
 *  Wall Game Object
 *
 *  Implements protective walls.
 *
 */
public class Wall extends GameObject implements warlordstest.IWall{

    public Wall (PlayerNumberType player, int xPos, int yPos){
        setPlayer(player);
        setWidth(30);
        setHeight(30);
        setXPos(xPos);
        setYPos(yPos);

        // Set wall image based on controlling player
        switch (this.getPlayer()) {
            case PLAYER_ONE:
                setSprite(new Image("/images/player1Wall.png"));
                break;
            case PLAYER_TWO:
                setSprite(new Image("/images/player2Wall.png"));
                break;
            case PLAYER_THREE:
                setSprite(new Image("/images/player3Wall.png"));
                break;
            case PLAYER_FOUR:
                setSprite(new Image("/images/player4Wall.png"));
                break;
        }
    }

    // Return if the wall is destroyed or not
    public boolean isDestroyed(){
    	return isDead();
	}
}