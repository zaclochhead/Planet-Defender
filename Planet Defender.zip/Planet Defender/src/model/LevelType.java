package model;

/**
 *  Level Type Enum
 *
 *  Represents the level to be played in the game. This will determine graphics.
 */
public enum LevelType {
    DEMO, ONE_MARS, TWO_MOON, THREE_EARTH
}
