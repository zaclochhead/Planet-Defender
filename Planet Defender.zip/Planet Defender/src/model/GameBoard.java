package model;

/**
 *  Gameboard models the existing game objects
 *
 *  This is to aid rendering and collision management
 *
 */
public class GameBoard {
    // Stores all game objects in a grid representation
    private GameObject[][] gameBoard;
    private int xMax, yMax;

    public GameBoard(int width, int height) {
        setxMax(width);
        setyMax(height);
        gameBoard = new GameObject[yMax][xMax];
    }

    // Return maximum Y dimension
    public int getyMax() {
        return this.yMax;
    }

    // Set maximum Y dimension
    private void setyMax(int max){
        this.yMax = max;
    }

    // Return maximum X dimension
    public int getxMax(){
        return this.xMax;
    }

    // Set maximum X dimension
    private void setxMax(int max){
        this.xMax = max;
    }

    // Adds object to game board
    public boolean addObject(GameObject objectToAdd){
        int xPos, yPos, width, height;
        xPos = objectToAdd.getXPos();
        yPos = objectToAdd.getYPos();
        width = objectToAdd.getWidth();
        height = objectToAdd.getHeight();

        // Insert object reference at all points
        for (int y = 0; y < width; y ++) {
            for (int x = 0; x < height; x ++){
                gameBoard[yPos+y][xPos+x] = objectToAdd;
            }
        }

        return true;
    }

    // Returns object at given x and y position (null if nothing)
    public GameObject getAt(int xPos, int yPos) {
        if ((xPos <= xMax) && (yPos <= yMax) && (yPos >= 0) && (xPos >= 0)) {
            return gameBoard[yPos][xPos];
        } else {
            return null;
        }
    }
}

