package model;

/**
 *  Moving object is the base class for moving objects
 *
 *  It inherits from game object and adds required velocity attributes
 *  for objects that move.
 */
public class Moving extends GameObject {
	private int xVelocity, yVelocity;

	Moving(){
		setXVelocity(0);
		setYVelocity(0);
		setCanMove();
	}

	public int getXVelocity() {
		return xVelocity;
	}

	public void setXVelocity(int dX) {
		this.xVelocity = dX;
	}

	public int getYVelocity() {
		return yVelocity;
	}

	public void setYVelocity(int dY) {
		this.yVelocity = dY;
	}
}
