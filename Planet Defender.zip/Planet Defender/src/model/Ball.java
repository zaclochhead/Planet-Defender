package model;
import control.GameControl;
import javafx.scene.image.Image;

import static java.lang.StrictMath.abs;

/**
 *  Ball implements a moving game object.
 *
 *  It stores the last player that collided with it, for implementing scoring
 */
public class Ball extends Moving implements warlordstest.IBall{
    private PlayerNumberType lastHitBy;
    private Image player1Ball = new Image("images/player1Ball.png");
	private Image player2Ball = new Image("images/player2Ball.png");
	private Image player3Ball = new Image("images/player3Ball.png");
	private Image player4Ball = new Image("images/player4Ball.png");

    public Ball(int difficulty) {
    	
    	setXPos(505);
		setYPos(377);
		setSprite(player1Ball);
		setWidth(15);
		setHeight(15);

		// Semi random velocity, to ensure that the ball doesn't end up traveling in
        // a direction with substantial difference between x and y.
        setXVelocity(difficulty+(int)(Math.random() * 6));
        setYVelocity(abs(getXVelocity())+3);
        if (Math.random() > 0.5) {
            setXVelocity(-getXVelocity());
        }
        if (Math.random() > 0.5) {
            setYVelocity(-getYVelocity());
        }
    }

    // Set last hit by as passed player
    public void setLastHitBy(PlayerNumberType player) {
        this.lastHitBy = player;
        this.updateSprite(player);
    }

    // Update the sprite to the player it was last hit by
    private void updateSprite(PlayerNumberType player) {
    	switch (player) {
			case PLAYER_ONE:
				setSprite(player1Ball);
				break;
			case PLAYER_TWO:
				setSprite(player2Ball);
				break;
			case PLAYER_THREE:
				setSprite(player3Ball);
				break;
			case PLAYER_FOUR:
				setSprite(player4Ball);
				break;
		}
	}

	// Return the player who last hit the ball
    public PlayerNumberType getLastHitBy() {
        return this.lastHitBy;
    }

	// Handles ball movements when unimpeded
	public void pass(){
		setXPos(getXPos()+getXVelocity());
		setYPos(getYPos()+getYVelocity());
	}

	// Handles collisions when the balls collides in the positive direction
	public void positiveBoundaryReflect(int X, int Y){
		
		//if the ball only collides in the x axis 
		if((getXPos()+getXVelocity())>=X){
			XReflect();
		}
		//if the ball only collides in the y axis 
		else{
			YReflect();
		}
	}

	// Handles collisions when the balls collides in the negative direction
	public void negativeBoundaryReflect(int X, int Y){
 
		if((getXPos()+getXVelocity())<=X){
			XReflect();
		}
		//if the ball only collides in the y axis 
		else{
			YReflect();
		}
	}
	//reflect the ball appropriately when it collides with another object 
	public void objectReflect(GameObject object){
		//the boundaries of the object the ball collides with 
		int objectTop = object.getYPos();
		int objectLeft = object.getXPos();
		int objectBottom = object.getYPos()+object.getHeight();
		int objectRight = object.getXPos()+object.getWidth();
		//the boundaries of the ball 
		int ballLeft = getXPos();
		int ballRight = getXPos()+getWidth();
		int ballTop = getYPos();
		int ballBottom = getYPos()+getHeight();
		//if the balls moving down and right it can hit the top or left of the object 
		if(getXVelocity()>0 && getYVelocity()>0){
			//if the ball hits left side of object
			if((ballRight-objectLeft)<(ballBottom-objectTop)){
				XReflect();				
				}
			//if the ball hits the top side of object 
			else{
				YReflect();
			}
		}
		//if the balls moving down and left it can hit top or right side of the object 
		else if(getXVelocity()<0 && getYVelocity()>0){
			//if the ball hits right side of object
			if((objectRight-ballLeft)<(ballBottom-objectTop)){
				XReflect();
			}
			//if the ball hits the top side of object 
			else{
				YReflect();
			}
		}
		//if the balls moving up and right it can hit bottom or left side of the object 
		else if(getXVelocity()>0 && getYVelocity()<0){
			//if the ball hits left side of object
			if((ballRight-objectLeft)<(objectBottom-ballTop)){
				XReflect();
			}
			//if the ball hits the bottom side of the object 
			else{
				YReflect();
			}
		}
		//if the balls moving up and left it can hit bottom or right side of the object 
		else if(getXVelocity()<0 && getYVelocity()<0){
			//if the ball hits right side of object
			if((objectRight-ballLeft)<(objectBottom-ballTop)){
				XReflect();
			}
			//if the ball hits the bottom side of the object 
			else{
				YReflect();
			}
		}	
	}
	
	//reflects the ball appropriately when it collides with a paddle 
	//covers special cases not in objectReflect and considers momentum 
	public void paddleReflect(Paddle paddle){
		//the boundaries of the paddle 
		int objectTop = paddle.getYPos();
		int objectLeft = paddle.getXPos();
		int objectBottom = paddle.getYPos()+paddle.getHeight();
		int objectRight = paddle.getXPos()+paddle.getWidth();
		//the boundaries of the ball
		int ballLeft = getXPos();
		int ballRight = getXPos()+getWidth();
		int ballTop = getYPos();
		int ballBottom = getYPos()+getHeight();
		//the paddles player 
		PlayerNumberType paddlePlayer = paddle.getPlayer();
			
			//ball and paddle moving right 
			if(paddle.getXVelocity()>0 && getXVelocity()>0){
				//if the balls hitting player ones or twos paddle
				if(paddlePlayer == PlayerNumberType.PLAYER_ONE
				||paddlePlayer ==PlayerNumberType.PLAYER_TWO){
					//if the balls coming from the front 
					if(getYVelocity()<0){
						//if the balls hitting the right side of the object 
						if((objectRight-ballLeft)<(objectBottom-ballTop)
						   && (objectRight-ballLeft)<(ballRight-objectLeft)
						   &&(objectRight-ballLeft)<(ballBottom-objectTop)){
							XReflect();
						}
						//if the ball hits any other side can reflect normally 
						else{
							objectReflect(paddle);
						}
					}
					//if the balls coming from the back
					else{
						//if the ball hits the right side of the object
						if((objectRight-ballLeft)<(ballBottom-objectTop)
						  && (objectRight-ballLeft)<(ballRight-objectLeft)
						  &&(objectRight-ballLeft<(objectBottom-ballTop))){
							XReflect();
						}
						//if the ball hits any other side can reflect normally 
						else{
							objectReflect(paddle);
						}
					}
				}
				//if the balls hitting player three or fours paddle
				else if(paddlePlayer == PlayerNumberType.PLAYER_THREE
				||paddlePlayer ==PlayerNumberType.PLAYER_FOUR){
					//if the balls coming from the front 
					if(getYVelocity()>0){
						//if the ball hits the right side of paddle 
						if((objectRight-ballLeft)<(ballBottom-objectTop)
						&&(objectRight-ballLeft)<(ballRight-objectLeft)&&
						(objectRight-ballLeft)<(objectBottom-ballTop)){
							XReflect();
						}
						//if the ball hits any other side can reflect normally 
						else{
							objectReflect(paddle);
						}
					}
					//if the balls coming from the back
					else{
						if((objectRight-ballLeft)<(objectBottom-ballTop)
							&& (objectRight-ballLeft)<(ballRight-objectLeft)&&
							(objectRight-ballLeft)<(ballBottom-objectTop)){
							XReflect();
						}
						else{
							objectReflect(paddle);
						}
					}
				}
					
				//if paddles faster than the ball then increase the balls speed 
				if(paddle.getXVelocity()>getXVelocity()){
					setXVelocity(paddle.getXVelocity()+2);
				}
			}
			
			
			//PADDLE AND BALL MOVING LEFT 
			else if(paddle.getXVelocity()<0 && getXVelocity()<0){
				//if the balls hitting player ones or twos paddle
				if(paddlePlayer == PlayerNumberType.PLAYER_ONE
				||paddlePlayer ==PlayerNumberType.PLAYER_TWO){
					//if the balls coming from the front 
					if(getYVelocity()<0){
						//if the ball hits the left side of the object
						if((ballRight-objectLeft)<(objectBottom-ballTop)
							&&(ballRight-objectLeft)<(objectRight-ballLeft)
							&&(ballRight-objectLeft)<(ballBottom-objectTop)){
							XReflect();
						}
						//if the ball hits any other side it can reflect normally 
						else{
							objectReflect(paddle);
						}
					}
					//if the balls coming from the back
					else{
						if((ballRight-objectLeft)<(ballBottom-objectTop)
								&&(ballRight-objectLeft)<(objectRight-ballLeft)
								&&(ballRight-objectLeft)<(objectBottom-ballTop)){
							XReflect();
						}
						else{
							objectReflect(paddle);
						}
					}
				}
				//if the balls hitting player three or fours paddle
				else if(paddlePlayer == PlayerNumberType.PLAYER_THREE
				||paddlePlayer ==PlayerNumberType.PLAYER_FOUR){
					//if the balls coming from the front 
					if(getYVelocity()>0){
						//if the ball hits the left side of the object 
						if((ballRight-objectLeft)<(ballBottom-objectTop)
								&&(ballRight-objectLeft)<(objectRight-ballLeft)
								&&(ballRight-objectLeft)<(objectBottom-ballTop)){
							XReflect();
						}
						//if the ball hit any other side it can reflect normally 
						else{
							objectReflect(paddle);
						}
					}
					//if the balls coming from the back
					else{
						//if the ball hits the left side
						if((ballRight-objectLeft)<(objectBottom-ballTop)
								&&(ballRight-objectLeft)<(objectRight-ballLeft)
								&&(ballRight-objectLeft)<(ballBottom-objectTop)){
							XReflect();
						}
						else{
							//if the ball hits any other side it can reflect normally
							objectReflect(paddle);
						}
					}
				}
				//if the paddles traveling faster than the ball than increase the balls velocity
				if(paddle.getXVelocity()<getXVelocity()){
					setXVelocity(paddle.getXVelocity()-2);
				}
			}
			//PADDLE AND BALL MOVING UP 
			else if(paddle.getYVelocity()<0 && getYVelocity()<0){
				//if the balls hitting player ones or threes paddle
				if(paddlePlayer == PlayerNumberType.PLAYER_ONE
				||paddlePlayer ==PlayerNumberType.PLAYER_THREE){
					//if the balls coming from the front 
					if(getXVelocity()<0){
						//if the ball hits the top of the paddle
						if((ballBottom-objectTop)<(objectRight-ballLeft)
								&& (ballBottom-objectTop)<(objectBottom-ballTop)
								&&(ballBottom-objectTop)<(ballRight-objectLeft)){
							YReflect();
						}
						//if the ball hits any other side it can reflect normally 
						else{
							objectReflect(paddle);
						}
					}
					//if the balls coming from the back
					else{
						//if the ball hits the top of the paddle
						if((ballBottom-objectTop)<(ballRight-objectLeft)
								&& (ballBottom-objectTop)<(objectBottom-ballTop)
								&&(ballBottom-objectTop)<(objectRight-ballLeft)){
							YReflect();
						}
						//if the ball hits any other side it can reflect normally 
						else{
							objectReflect(paddle);
						}
					}
				}
				//if the balls hitting player two or fours paddle
				else if(paddlePlayer == PlayerNumberType.PLAYER_TWO
				||paddlePlayer ==PlayerNumberType.PLAYER_FOUR){
					//if the balls coming from the front 
					if(getXVelocity()>0){
						//if the ball hits the top of the paddle 
						if((ballBottom-objectTop)<(ballRight-objectLeft)
								&& (ballBottom-objectTop)<(objectBottom-ballTop)
								&&(ballBottom-objectTop)<(objectRight-ballLeft)){
							YReflect();
						}
						//if the ball hits any other side it can reflect normally 
						else{
							objectReflect(paddle);
						}
					}
					//if the balls coming from the back
					else{
						if((ballBottom-objectTop)<(objectRight-ballLeft)
								&& (ballBottom-objectTop)<(objectBottom-ballTop)
								&&(ballBottom-objectTop)<(ballRight-objectLeft)){
							YReflect();
						}
						//if the ball hits any other side it can reflect normally 
						else{
							objectReflect(paddle);
						}
					}
				}
				//if the paddles moving faster than the ball than increase the balls velocity
				if(paddle.getYVelocity()<=getYVelocity()){
					setYVelocity(paddle.getYVelocity()-2);
				}
			}
			//PADDLE AND BALL MOVING DOWN  
			else if(paddle.getYVelocity()>0 && getYVelocity()>0){
				//if the balls hitting player ones or threes paddle
				if(paddlePlayer == PlayerNumberType.PLAYER_ONE
				||paddlePlayer ==PlayerNumberType.PLAYER_THREE){
					//if the balls coming from the front 
					if(getXVelocity()<0){
						//if the ball hits the bottom of the paddle 
						if((objectBottom-ballTop)<(objectRight-ballLeft)
								&&(objectBottom-ballTop)<(ballBottom-objectTop)&&
								(objectBottom-ballTop)<(ballRight-objectLeft)){
							YReflect();
						}
						//if the ball hits any other side it can reflect normally 
						else{
							objectReflect(paddle);
						}
					}
					//if the balls coming from the back
					else{
						//if the ball hits the bottom of the paddle 
						if((objectBottom-ballTop)<(ballRight-objectLeft)
								&&(objectBottom-ballTop)<(ballBottom-objectTop)
								&&(objectBottom-ballTop)<(ballRight-objectLeft)){
							YReflect();
						}
						//if the ball hits any other side it can reflect normally 
						else{
							objectReflect(paddle);
						}
					}
				}
				//if the balls hitting player two or fours paddle
				else if(paddlePlayer == PlayerNumberType.PLAYER_TWO
				||paddlePlayer ==PlayerNumberType.PLAYER_FOUR){
					//if the balls coming from the front 
					if(getXVelocity()>0){
						//if the ball hits the bottom of the paddle
						if((objectBottom-ballTop)<(ballRight-objectLeft)
								&&(objectBottom-ballTop)<(ballBottom-objectTop)
								&&(objectBottom-ballTop)<(objectRight-ballLeft)){
							YReflect();
						}
						//if the ball hits any other side it can reflect normally 
						else{
							objectReflect(paddle);
						}
					}
					//if the balls coming from the back
					else{
						//if the ball hits the bottom of the paddle
						if((objectBottom-ballTop)<(objectRight-ballLeft)
								&&(objectBottom-ballTop)<(ballBottom-objectTop)
								&&(objectBottom-ballTop)<(ballRight-objectLeft)){
							YReflect();
						}
						else{
							//if the ball hits any other side it can reflect normally 
							objectReflect(paddle);
						}
					}
				}
				//if the paddles moving faster than the ball than increase the balls velocity
				if(paddle.getYVelocity()>getYVelocity()){
					setYVelocity(paddle.getYVelocity()+2);
				}
			}
			//paddle moving up and ball moving down  
				else if(paddle.getYVelocity()<0 && getYVelocity()>0){
					//reflect normally
					objectReflect(paddle);
					//if the paddles moving faster than the ball than increase the balls velocity
					if(-1*paddle.getYVelocity()>=getYVelocity()){
						setYVelocity(paddle.getYVelocity()-2);
					}
				}
			//paddle moving down and ball moving up 		
				else if(paddle.getYVelocity()>0 && getYVelocity()<0){
					//reflect normally
					objectReflect(paddle);
					//if the paddles moving faster than the ball than increase the balls velocity
					if(paddle.getYVelocity()>=-1*getYVelocity()){
						setYVelocity(paddle.getYVelocity()+2);
					}
				}
			//paddle moving right and ball moving left 
				else if(paddle.getXVelocity()>0 && getXVelocity()<0){
					objectReflect(paddle);
					//if the paddles moving faster than the ball than increase the balls velocity
					if(paddle.getXVelocity()>=-1*getXVelocity()){
						setYVelocity(paddle.getXVelocity()+2);
					}
				}
			//paddle moving left and ball moving right
				else if(paddle.getXVelocity()<0 && getXVelocity()>0){
					objectReflect(paddle);
					//if the paddles moving faster than the ball than increase the balls velocity
					if(-1*paddle.getXVelocity()>=getXVelocity()){
						setYVelocity(paddle.getXVelocity()-2);
					}
				}
			//paddles not moving
				else{
					objectReflect(paddle);
				}
		
		}
	
	
	// Reverses the y direction if the ball collides in the y axis 
	private void YReflect(){
	setYVelocity(getYVelocity()*-1);
	}
	
	//Reverses the x direction if the ball collides in the x axis 
	private void XReflect(){
		setXVelocity(getXVelocity()*-1);
	}
	
}