package model;

/**
 * Player number type enum to manage object ownership
 * tracking.
 *
 * This will be relevant for scoring points and managing win conditions.
 */
public enum PlayerNumberType {
	PLAYER_ONE,PLAYER_TWO,PLAYER_THREE,PLAYER_FOUR, NONE
}
