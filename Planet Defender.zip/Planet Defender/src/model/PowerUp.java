package model;
import control.PaddleControl;
import javafx.scene.image.Image;

public class PowerUp extends GameObject {
//determines type of powerup to run 
double powerUpType;
private PlayerAvatar p1,p2,p3,p4;
private PaddleControl pc1,pc2,pc3,pc4;
private Wall wall1,wall2,wall3,wall4;
private Ball gameball;
private GameBoard gameBoard;
private int difficulty;
	public PowerUp(Ball gameball, PlayerAvatar p1,PlayerAvatar p2,
		PlayerAvatar p3,PlayerAvatar p4,PaddleControl pc1, PaddleControl pc2,
		PaddleControl pc3,PaddleControl pc4,Wall wall1,Wall wall2, Wall wall3,Wall wall4,
		GameBoard gameBoard,int difficulty){
		
		this.gameball=gameball;
		setWidth(40);
		setHeight(40);
		//set the x and y position of the powerups to respawn randomly throughout the game 
		int xPos = (335+(int)(Math.random() * (355)));
		int yPos = (335+(int)(Math.random() * (115)));
		
		if(xPos>497 && xPos<513){
			xPos = 530;
		}
		if(yPos>369 && xPos<385){
			xPos = 530;
		}
		setXPos(xPos);
		setYPos(yPos);
		
		this.p1 = p1;
		this.p2=p2;
		this.p3=p3;
		this.p4=p4;
		this.pc1=pc1;
		this.pc2=pc2;
		this.pc3=pc3;
		this.pc4=pc4;
		this.wall1=wall1;
		this.wall2=wall2;
		this.wall3=wall3;
		this.wall4=wall4;
		this.gameBoard=gameBoard;
		this.difficulty = difficulty;
		
		//make the powerup type random 
		powerUpType = Math.random()*1;
		
		//if the ball speed up power up is running than set speed up image 
		if(powerUpType<=.25){
		setSprite(new Image("/images/speedupball.jpg"));
		}
		//if the paddle bigger power up is running than set the makebigger image 
	   	else if(powerUpType>0.25 && powerUpType<=0.50){
		setSprite(new Image("/images/makesbigger.jpg"));
	   	}
		//if the paddle faster power up is running than set the makes faster image 
	   	else if(powerUpType>0.5 && powerUpType<=0.75){
			setSprite(new Image("/images/makesfaster.png"));
	   	}
		//if the wall repair powerup is running than set the repair image 
	   	else{
			setSprite(new Image("/images/repair.png"));
	   	}
	}
	
	//the set power method applies the power up randomly 	
	 public void setPower(){
	   	if(powerUpType<=0.25){
	   		ballSpeedUp();
	   	}
	   	else if(powerUpType>0.25 && powerUpType<=0.50){
	   		paddleBigger();
	   	}
	   	else if(powerUpType>0.5 && powerUpType<=0.75){
	   		paddleSpeedUp();
	    }
	   	else{
	   		repair();
	   }
	 }
	 
	 //speed up the ball if the balls not at the maximum velocity 
	 private void ballSpeedUp(){
		//if the x velocities not at the max speed than speed the x up
		 if(gameball.getXVelocity()<0){
	   		if(gameball.getXVelocity()>=-15){
	   			gameball.setXVelocity(gameball.getXVelocity()-5);
	   		}
	   	}
	   	else if(gameball.getXVelocity()<=15){
	   		gameball.setXVelocity(gameball.getXVelocity()+5);	
	   	}
		 //if the y velocities not at the max speed than speed the y up
	   	if(gameball.getYVelocity()<0){
		  	if(gameball.getYVelocity()>=-15){
		   		gameball.setYVelocity(gameball.getYVelocity()-5);
		   	}
	   	}
	   	else if(gameball.getYVelocity()<=15){
		   	gameball.setYVelocity(gameball.getYVelocity()+5);	
		}	
	 }
	
	 //doubles the last hit by players paddle size if it hasn't been doubles already
	 private void paddleBigger(){
		 int superSize = 55;
		 
		 //if player 1 last then double paddle size if it hasn't been already
		 if(gameball.getLastHitBy()==p1.getPlayer()){
	   			if(p1.getPlayersPaddle().getHeight()==45){
		   			p1.getPlayersPaddle().setHeight(superSize);
		   			p1.getPlayersPaddle().setWidth(superSize);
	   			}
	   		}
	   		
	   		else if(gameball.getLastHitBy()==p2.getPlayer()){
	   		 //if player 2 last then double paddle size if it hasn't been already
	   			if(p2.getPlayersPaddle().getHeight()==45){
		   			p2.getPlayersPaddle().setHeight(superSize);
		   			p2.getPlayersPaddle().setWidth(superSize);
	   			}
	   		}
	   		else if(gameball.getLastHitBy()==p3.getPlayer()){
	   		 //if player 3 last then double paddle size if it hasn't been already
	   			if(p3.getPlayersPaddle().getHeight()==45){
		   			p3.getPlayersPaddle().setHeight(superSize);
		   			p3.getPlayersPaddle().setWidth(superSize);
	   			}
	   		}
	   		else if(gameball.getLastHitBy()==p4.getPlayer()){
	   		 //if player 4 last then double paddle size if it hasn't been already
	   			if(p4.getPlayersPaddle().getHeight()==45){
		   			p4.getPlayersPaddle().setHeight(superSize);
		   			p4.getPlayersPaddle().setWidth(superSize);
	   			}
	   		}
		}
	    //increases the maximum velocity of the paddle of the player that hit the ball last 
	 	private void paddleSpeedUp(){
	 		//if player 1 hit the ball last then increase paddle speed if it hasn't been increased already
	 		if(gameball.getLastHitBy()==p1.getPlayer()){
		   		if(pc1.getmaxVelocity()<18){
			   		pc1.setmaxVelocity(pc1.getmaxVelocity()+5);
		   		}
		   	}
	 		//if player 2 hit the ball last then increase paddle speed if it hasn't been increased already
		   	else if(gameball.getLastHitBy()==p2.getPlayer()){
		   		if(pc2.getmaxVelocity()<18){
			   		pc2.setmaxVelocity(pc2.getmaxVelocity()+5);
		   		}
		   	}
	 		//if player 3 hit the ball last then increase paddle speed if it hasn't been increased already
		   	else if(gameball.getLastHitBy()==p3.getPlayer()){
		   		if(pc3.getmaxVelocity()<18){
			   		pc3.setmaxVelocity(pc3.getmaxVelocity()+5);
		   		}
	   		}
	 		//if player 4 hit the ball last then increase paddle speed if it hasn't been increased already
	 		else if(gameball.getLastHitBy()==p4.getPlayer()){
	 			if(pc4.getmaxVelocity()<18){
			   		pc4.setmaxVelocity(pc4.getmaxVelocity()+5);
		   		}
		   	}
	 	}
	 	//repairs the walls of the player that hit the ball last 
	 	private void repair(){
	 		 // Determine number of AI walls to remove from default of 3
	        int layersToRemove;
	        if (difficulty == 1) {
	            layersToRemove = 2;
	        } else if (difficulty == 2) {
	            layersToRemove = 1;
	        } else {
	            layersToRemove = 0;
	        }
	 		//if player 1 hit the ball last then regenerate players 1s walls 
	 		if(gameball.getLastHitBy()==p1.getPlayer()){
	 			if(p1.isAlive()){
	 				p1.setWallsRemaining(0);
		 			for (int y = 0; y < 215; y += 30) {
		 	            for (int x = 0; x < 215; x +=30) {
		 	                if ((x > 135) || (y > 135)) {	 	           
		 	                	if(gameBoard.getAt(x, y).getObjectType()==ObjectType.WALL){

		 	                		wall1 = new Wall(PlayerNumberType.PLAYER_ONE, x, y);
		 	                		wall1.setObjectType(ObjectType.WALL);
		 	                		gameBoard.addObject(wall1);
		 	                		p1.setWallsRemaining(p1.getWallsRemaining()+1);
		 	                	}
		 	                }
		 	            }
		 	        }
	 			}
		   	}
	 		//if player 2 hit the ball last then regenerate players 2s walls 
		   	else if(gameball.getLastHitBy()==p2.getPlayer()){
		   		if(p2.isAlive()){
	 				p2.setWallsRemaining(0);
				    for (int y = 0; y <= (215-(layersToRemove * 30)); y += 30) {
				       for (int x = 1024-30; x >= 1024-245+(layersToRemove * 30); x -= 30) {
				           if (((x < 1024-165)) || (y > 135)) {
		 	                	if(gameBoard.getAt(x, y).getObjectType()==ObjectType.WALL){

				        	    wall2 = new Wall(PlayerNumberType.PLAYER_TWO, x, y);
			 	             	wall2.setObjectType(ObjectType.WALL);
			 	                gameBoard.addObject(wall2);
			 	                p2.setWallsRemaining(p2.getWallsRemaining()+1);
		 	                	}
			 	           }
			 	       }
			 	    }
		   		}
		   	}
	 		//if player 3 hit the ball last then regenerate players 1s walls 
		   	else if(gameball.getLastHitBy()==p3.getPlayer()){
		   		if(p3.isAlive()){
	 				p3.setWallsRemaining(0);
			   		for (int y = 768-30; y >= 768-245+(layersToRemove * 30); y -= 30) {
			            for (int x = 0; x <= 215-(layersToRemove * 30); x += 30) {
			                if (((x > 135)) || (y < (768-165))) {
		 	                	if(gameBoard.getAt(x, y).getObjectType()==ObjectType.WALL){

		 	                		wall3 = new Wall(PlayerNumberType.PLAYER_THREE, x, y);
		 	                		wall3.setObjectType(ObjectType.WALL);
		 	                		gameBoard.addObject(wall3);
		 	                		p3.setWallsRemaining(p3.getWallsRemaining()+1);
		 	                	}
		 	                }
		 	            }
		 	        }
		   		}
	   		}
	 		//if player  hit the ball last then regenerate players 1s walls 
	 		else if(gameball.getLastHitBy()==p4.getPlayer()){
	 			if(p4.isAlive()){
	 				p4.setWallsRemaining(0);
		 			for (int y = 768-30; y >= 768-245+(layersToRemove * 30); y -= 30) {
		 	            for (int x = 1024-30; x >= 1024-245+(layersToRemove * 30); x -= 30) {
		 	                if (((x < 1024-165)) || (y < (768-165))) {
		 	                	if(gameBoard.getAt(x, y).getObjectType()==ObjectType.WALL){
		 	                		wall4 = new Wall(PlayerNumberType.PLAYER_FOUR, x, y);
		 	                		wall4.setObjectType(ObjectType.WALL);
		 	                		gameBoard.addObject(wall4);
		 	                		p4.setWallsRemaining(p4.getWallsRemaining()+1);
		 	                	}
		 	                }
		 	            }
		 	        }
	 			}
		   	}
	 	}
	}