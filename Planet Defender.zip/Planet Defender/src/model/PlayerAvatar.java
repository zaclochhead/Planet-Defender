package model;

import javafx.scene.image.Image;

/**
 *  Player avatar represents each player as well as maintains
 *  relevant player information (score, winner)
 *
 */
public class PlayerAvatar extends GameObject implements warlordstest.IWarlord {
    private boolean winner;
    private int wallsRemaining;
    private int score;
    private Paddle paddle;

    public PlayerAvatar(PlayerNumberType player,Paddle paddle){
        setWinner(false);
        setAlive();
        setScore(0);
        setPlayer(player);
        setWidth(100);
        setHeight(100);
        setWallsRemaining(0);
        this.paddle = paddle;

        // Based on player, set image and x and y positions.
        switch (this.getPlayer()) {
            // Set images to default of DEMO mode. These are changed based on current
            // level in GameControl.
            case PLAYER_ONE:
                setSprite(new Image("/images/earth.png"));
                setXPos(0);
                setYPos(0);
                break;
            case PLAYER_FOUR:
                setSprite(new Image("/images/alien1.png"));
                setXPos(1024-this.getWidth());
                setYPos(768-this.getHeight());
                break;
            case PLAYER_THREE:
                setSprite(new Image("/images/mars.png"));
                setXPos(0);
                setYPos(768-this.getHeight());
                break;
            case PLAYER_TWO:
                setSprite(new Image("/images/moon.png"));
                setXPos(1024-this.getWidth());
                setYPos(0);
                break;
        }

    }

    // Get the number of walls this player has remaining
    public int getWallsRemaining() {
        return wallsRemaining;
    }

    // Set the number of walls this player has remaining
    public void setWallsRemaining(int wallsRemaining) {
        this.wallsRemaining = wallsRemaining;
    }

    // Get this players paddle
    public Paddle getPlayersPaddle(){
    	return this.paddle;
    }

    // Get this players score
    public int getScore(){
        return this.score;
    }

    // Set this players score
    public void setScore(int newScore){
        this.score = newScore;
    }

    // Set this player as the winner
    public void setWinner(boolean isWinner) {
        this.winner = isWinner;
    }

    // Increase this players score
    public void incrementScore(){
    	this.score++;
    }

    // Return if this player is the winner
    public boolean hasWon() {
        return this.winner;
    }
}
