package model;

import javafx.scene.image.Image;

/**
 *  Game object is the base class for all game objects.
 *
 *  All game objects inherit from this.
 *
 *  Contains basic attributes required for all game elements.
 *  Along with their getters and setters as required.
 */
public class GameObject {
    private int xPos, yPos;

    // Width, height and sprite for GUI
    private int width, height;
    private Image sprite;

    private boolean alive, movingObject;
    private PlayerNumberType player;
    private ObjectType type;

    GameObject(){
        setXPos(0);
        setYPos(0);
        setAlive();
        setPlayer(PlayerNumberType.PLAYER_ONE);
        movingObject = false;
    }

    public PlayerNumberType getPlayer() {
        return this.player;
    }

    public void setPlayer(PlayerNumberType player) {
        this.player = player;
    }
    
    public void setObjectType(ObjectType type){
    	this.type = type;
    }

    public ObjectType getObjectType(){
    	return type;
    }

    public int getXPos(){
        return xPos;
    }

    public void setXPos(int newXPos){
        this.xPos = newXPos;
    }

    public int getYPos(){
        return yPos;
    }

    public void setYPos(int newYPos){
        this.yPos = newYPos;
    }

    public void setDead() {
        this.alive = false;
    }

    public void setAlive() {
        this.alive = true;
    }

    public boolean isAlive() {
        return this.alive;
    }

    public boolean isDead(){
    	if(isAlive()){
    		return false;
    	}
    	else{
    		return true;
    	}
    }

    public Image getSprite() {
        return this.sprite;
    }

    public void setSprite(Image sprite) {
        this.sprite = sprite;
    }

    public int getHeight() {
        return height;
    }

    // Defaults to package private
    void setHeight(int height) {
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    // Defaults to package private
    void setWidth(int width) {
        this.width = width;
    }

    // Defaults to package private
    void setCanMove() {
        this.movingObject = true;
    }

}