package model;
import javafx.scene.image.Image;
import javafx.scene.canvas.GraphicsContext;
import javafx.geometry.Rectangle2D;
public class Sprite{
	
	 	//gets the boundaries of the input object
	    public Rectangle2D getBoundary(GameObject gameobject)
	    {
	        return new Rectangle2D(gameobject.getXPos(),gameobject.getYPos(),gameobject.getHeight(),gameobject.getWidth());
	    }
	    //returns a boolean if one object intersects the other 
	    public boolean intersects(Sprite s,GameObject gameobject)
	    {
	        return s.getBoundary(gameobject).intersects( this.getBoundary(gameobject) );
	    }
}
