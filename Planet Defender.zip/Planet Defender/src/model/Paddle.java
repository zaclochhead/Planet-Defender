package model;

import javafx.scene.image.Image;

/**
 *  Paddle objects are moving game objects.
 *
 *  Defined here are the paddle sprite, width and height.
 *
 */
public class Paddle extends Moving implements warlordstest.IPaddle{
    public Image spriteX, spriteY;

    public Paddle(PlayerNumberType player) {
        this.setPlayer(player);

        // Based on player, determine which images to use as x and y sprites
        // X sprite will be used when the paddle is traveling in the x direction
        // and Y sprite when travelling in the Y direction.
        switch (this.getPlayer()) {
            case PLAYER_ONE:
                spriteX = new Image("/images/player1Paddle_X.png");
                spriteY = new Image("/images/player1Paddle_Y.png");
                setSprite(spriteX);
                break;
            case PLAYER_TWO:
                spriteX = new Image("/images/player2Paddle_X.png");
                spriteY = new Image("/images/player2Paddle_Y.png");
                setSprite(spriteX);
                break;
            case PLAYER_THREE:
                spriteX = new Image("/images/player3Paddle_X.png");
                spriteY = new Image("/images/player3Paddle_Y.png");
                setSprite(spriteX);
                break;
            case PLAYER_FOUR:
                spriteX = new Image("/images/player4Paddle_X.png");
                spriteY = new Image("/images/player4Paddle_Y.png");
                setSprite(spriteX);
                break;
        }

        // Setup paddle width and height
        this.setHeight(45);
        this.setWidth(45);
    }
}