package view;

import control.*;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import model.LevelType;

import java.util.ArrayList;

public class GUI extends Application {

    // Prepare window
    private Stage window;
    private Scene gameScreen, splashScreen;

    // Window dimensions
    private int width = 1024;
    private int height = 768;

    // Game screen globals
    private final Canvas gameCanvas = new Canvas(width, height);
    private GraphicsContext gameGC = gameCanvas.getGraphicsContext2D();
    private final Group gameRoot = new Group();

    // Reference to game control (for the current game we are playing)
    private GameControl gameControl;

    // Hold input
    private ArrayList<String> input = new ArrayList<>();

    // Game background
    private Image gameBackground;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        // Using window for clarity as window refers to
        window = primaryStage;

        window.setTitle("Planet Defender");

        // Prevent the user from resizing the window
        window.setMaxHeight(height+28);
        window.setMaxWidth(width);
        window.setMinHeight(height+28);
        window.setMinWidth(width);

        /*
         * SPLASH
         */
        Group splashRoot = new Group();
        splashScreen = new Scene(splashRoot);

        // Declaration of splash canvas and background image
        Canvas splashCanvas = new Canvas(width, height);
        GraphicsContext splashGC = splashCanvas.getGraphicsContext2D();
        splashGC.drawImage(new Image("/images/splashBackground.png"), 0, 0, width, height);
        splashRoot.getChildren().add(splashCanvas);

        // Declaration and configuration of button container
        VBox buttonContainer = new VBox(8);
        buttonContainer.setMinHeight(height - 180);
        buttonContainer.setMinWidth(width);
        buttonContainer.setLayoutY(180);
        buttonContainer.setAlignment(Pos.CENTER);
        buttonContainer.setBackground(Background.EMPTY);
        splashRoot.getChildren().add(buttonContainer);

        // Declaration of buttons
        Button onePlayerGame = new Button("Story Mode - One Player");
        Button arcadeGame = new Button("Arcade Mode - One Player");
        Button twoPlayerGame = new Button("Multiplayer - Two Players");
        Button threePlayerGame = new Button("Multiplayer - Three Players");
        Button fourPlayerGame = new Button("Multiplayer - Four Players");
        Button demoMode = new Button("Demo Mode");
        Button exitGame = new Button("Exit Game");

        // Add buttons to button container
        buttonContainer.getChildren().addAll(onePlayerGame, arcadeGame, twoPlayerGame, threePlayerGame,
                fourPlayerGame, demoMode, exitGame);

        // Setup first scene to be displayed as splash
        window.setScene(splashScreen);

        // Show window
        window.show();

        // Game screen initialisation (see declaration in global)
        gameScreen = new Scene(gameRoot);
        gameRoot.getChildren().add(gameCanvas);

        /*
         * Screen Declaratons Here
         */
        Group gameIntroScreenRoot = new Group();
        Scene gameIntroScreen = new Scene(gameIntroScreenRoot);
        Group mpIntroScreenRoot = new Group();
        Scene mpIntroScreen = new Scene(mpIntroScreenRoot);
        Group preLevel1ScreenRoot = new Group();
        Scene preLevel1Screen = new Scene(preLevel1ScreenRoot);
        Group preLevel2ScreenRoot = new Group();
        Scene preLevel2Screen = new Scene(preLevel2ScreenRoot);
        Group preLevel3ScreenRoot = new Group();
        Scene preLevel3Screen = new Scene(preLevel3ScreenRoot);
        Group postLevel3ScreenRoot = new Group();
        Scene postLevel3Screen = new Scene(postLevel3ScreenRoot);

        /*
         *  Multiplayer Intro Screen
         */
        // Declaration of splash canvas and background image
        Canvas mpIntroScreenCanvas = new Canvas(width, height);
        GraphicsContext mpIntroScreenGC = mpIntroScreenCanvas.getGraphicsContext2D();
        mpIntroScreenGC.drawImage(new Image("/images/multiplayerInstructionsScreen.png"), 0, 0, width, height);
        mpIntroScreenRoot.getChildren().add(mpIntroScreenCanvas);

        // Event handling for this screen
        mpIntroScreen.setOnKeyPressed(e->{
            String code = e.getCode().toString();
            if (code.equals("ENTER")) {
                window.setScene(gameScreen);
                printGameBoard();
                countDown.start();
            } else if (code.equals("ESCAPE")) {
                window.setScene(splashScreen);
            }
        });
        
        /*
         *  Game Intro Screen
         */
        // Declaration of splash canvas and background image
        Canvas gameIntroScreenCanvas = new Canvas(width, height);
        GraphicsContext gameIntroScreenGC = gameIntroScreenCanvas.getGraphicsContext2D();
        gameIntroScreenGC.drawImage(new Image("/images/spIntroScreen.png"), 0, 0, width, height);
        gameIntroScreenRoot.getChildren().add(gameIntroScreenCanvas);

        // Event handling for this screen
        gameIntroScreen.setOnKeyPressed(e->{
            String code = e.getCode().toString();
            if (code.equals("ENTER")) {
                window.setScene(preLevel1Screen);
            } else if (code.equals("ESCAPE")) {
                window.setScene(splashScreen);
            }
        });

        /*
         *  Pre Level 1 Screen
         */
        // Declaration of splash canvas and background image
        Canvas preLevel1ScreenCanvas = new Canvas(width, height);
        GraphicsContext preLevel1ScreenGC = preLevel1ScreenCanvas.getGraphicsContext2D();
        preLevel1ScreenGC.drawImage(new Image("/images/marsInterludeScreen.png"), 0, 0, width, height);
        preLevel1ScreenRoot.getChildren().add(preLevel1ScreenCanvas);

        // Event handling for this screen
        preLevel1Screen.setOnKeyPressed(e->{
            String code = e.getCode().toString();
            if (code.equals("ENTER")) {
                window.setScene(gameScreen);
                countDown.start();
            } else if (code.equals("ESCAPE")) {
                window.setScene(splashScreen);
            }
        });

        /*
         *  Pre Level 2 Screen
         */
        Canvas preLevel2ScreenCanvas = new Canvas(width, height);
        GraphicsContext preLevel2ScreenGC = preLevel2ScreenCanvas.getGraphicsContext2D();
        preLevel2ScreenGC.drawImage(new Image("/images/moonInterludeScreen.png"), 0, 0, width, height);
        preLevel2ScreenRoot.getChildren().add(preLevel2ScreenCanvas);

        // Event handling for this screen
        preLevel2Screen.setOnKeyPressed(e->{
            String code = e.getCode().toString();
            if (code.equals("ENTER")) {
                setupGameWindowAndControl(1,2, LevelType.TWO_MOON);
                window.setScene(gameScreen);
                countDown.start();
            } else if (code.equals("ESCAPE")) {
                window.setScene(splashScreen);
            }
        });

        /*
         *  Pre Level 3 Screen
         */
        Canvas preLevel3ScreenCanvas = new Canvas(width, height);
        GraphicsContext preLevel3ScreenGC = preLevel3ScreenCanvas.getGraphicsContext2D();
        preLevel3ScreenGC.drawImage(new Image("/images/earthInterludeScreen.png"), 0, 0, width, height);
        preLevel3ScreenRoot.getChildren().add(preLevel3ScreenCanvas);

        // Event handling for this screen
        preLevel3Screen.setOnKeyPressed(e->{
            String code = e.getCode().toString();
            if (code.equals("ENTER")) {
                setupGameWindowAndControl(1,3, LevelType.THREE_EARTH);
                window.setScene(gameScreen);
                countDown.start();
            } else if (code.equals("ESCAPE")) {
                window.setScene(splashScreen);
            }
        });

        /*
         *  Post Level 3 Screen
         */
        Canvas postLevel3ScreenCanvas = new Canvas(width, height);
        GraphicsContext postLevel3ScreenGC = postLevel3ScreenCanvas.getGraphicsContext2D();
        postLevel3ScreenGC.drawImage(new Image("/images/winScreen.png"), 0, 0, width, height);
        postLevel3ScreenRoot.getChildren().add(postLevel3ScreenCanvas);

        // Event handling for this screen
        postLevel3Screen.setOnKeyPressed(e -> window.setScene(splashScreen));

        /*
         *  Manage Events For Splash Screen
         */
        // One player game selected
        onePlayerGame.setOnKeyPressed(e -> {
            if (e.getCode().toString().equals("ENTER")) {
                setupGameWindowAndControl(1,1, LevelType.ONE_MARS);
                window.setScene(gameIntroScreen);
            }
        });

        // One player arcade game selected
        arcadeGame.setOnKeyPressed(e -> {
            if (e.getCode().toString().equals("ENTER")) {
                setupGameWindowAndControl(1,3, LevelType.DEMO);
                window.setScene(gameScreen);
                countDown.start();
            }
        });

        // Two player multiplayer game selected
        twoPlayerGame.setOnKeyPressed(e -> {
            if (e.getCode().toString().equals("ENTER")) {
                setupGameWindowAndControl(2,3, LevelType.DEMO);
                window.setScene(mpIntroScreen);
            }
        });

        // Three player multiplayer game selected
        threePlayerGame.setOnKeyPressed(e -> {
            if (e.getCode().toString().equals("ENTER")) {
                setupGameWindowAndControl(3,3, LevelType.DEMO);
                window.setScene(mpIntroScreen);
            }
        });

        // Four player multiplayer game selected
        fourPlayerGame.setOnKeyPressed(e -> {
            if (e.getCode().toString().equals("ENTER")) {
                setupGameWindowAndControl(4,3, LevelType.DEMO);
                window.setScene(mpIntroScreen);
            }
        });

        // Demo mode selected
        demoMode.setOnKeyPressed(e -> {
            if (e.getCode().toString().equals("ENTER")) {
                setupGameWindowAndControl(0,3, LevelType.DEMO);
                countDown.start();
            }
        });

        // Exit game
        exitGame.setOnKeyPressed(e -> {
            if (e.getCode().toString().equals("ENTER")) {
                System.exit(0);
            }
        });

        /*
         *  Manage Events for the Game Screen
         */
        gameScreen.setOnKeyPressed(e -> {
            // Convert key press to string
            String code = e.getCode().toString();

            // If the key press was ESC or P key/s
            if ((code.equals("ESCAPE")) || (code.equals("P"))) {

                if ((code.equals("ESCAPE")) && (gameControl.getIsPaused())) {

                    // If the game is already paused, and the user has pressed ESC
                    // stop all animation timers
                    gameTimer.stop();
                    gameTick.stop();
                    countDown.stop();

                    // and return to main screen
                    window.setScene(splashScreen);

                } else if (!gameControl.getIsPaused()){

                    // The game is not paused, hence pause the game
                    pause();

                } else if ((code.equals("P")) && (gameControl.getIsPaused()) && (!gameControl.isFinished())) {

                    // The game is paused, and unfinished, hence un-pause the game
                    unPause();

                }
            } else if ((code.equals("E"))||(code.equals("PAGE DOWN"))) {

                // E or pg down keys were pressed, hence set the game time remaining to zero, to skip
                // to the end of a game.
                gameControl.setTimeRemaining(0);

            } else if ((gameControl.isFinished()) && (code.equals("ENTER")))  {

                // The game has finished. Determine which screen to progress to.
                switch (gameControl.getLevel()) {

                    // Level 1 has just finished
                    case ONE_MARS:
                        if (gameControl.getWinnerAsString().equals("Player 1")) {

                            // The player won, hence progress to level 2
                            setupGameWindowAndControl(1,2, LevelType.TWO_MOON);
                            window.setScene(preLevel2Screen);

                        } else {

                            // The player lost, hence restart level
                            setupGameWindowAndControl(1,1, LevelType.ONE_MARS);
                            window.setScene(preLevel1Screen);

                        }
                        break;

                    // Level 2 has just finished
                    case TWO_MOON:
                        if (gameControl.getWinnerAsString().equals("Player 1")) {

                            // The player won, hence progress to level 3
                            setupGameWindowAndControl(1,3, LevelType.THREE_EARTH);
                            window.setScene(preLevel3Screen);

                        } else {

                            // The player lost, hence restart level
                            setupGameWindowAndControl(1,2, LevelType.TWO_MOON);
                            window.setScene(preLevel2Screen);

                        }
                        break;

                    // Level 3 has just finished
                    case THREE_EARTH:
                        if (gameControl.getWinnerAsString().equals("Player 1")) {

                            // The player has won the game, hence display game completed screen
                            window.setScene(postLevel3Screen);

                        } else {

                            // The player has lost, hence restart level 3
                            setupGameWindowAndControl(1,3, LevelType.THREE_EARTH);
                            window.setScene(preLevel3Screen);

                        }
                        break;

                    // Demo has finished
                    default:
                        if ((code.equals("ENTER")) || (code.equals("ESCAPE"))) {

                            // Hence return to main screen
                            window.setScene(splashScreen);

                        }
                }
            } else if (!input.contains(code)) {
                // If the input hasn't already been registered, add to the input array.
                input.add(code);
            }

        });

        // If the input is removed (ie key released) remove the key from the input array.
        gameScreen.setOnKeyReleased(e -> input.remove(e.getCode().toString()));

    }

    /**
     *  Count Down Animation Timer
     *  Manages the 3 second count down before a game starts/
     *  is resumed from a pause.
     */
    private AnimationTimer countDown = new AnimationTimer() {

        // Defaults to package private scope
        int count = 3;

        private long lastUpdate = 0 ;

        @Override
        public void handle(long currentNanoTime) {
            if (currentNanoTime - lastUpdate >= 1_000_000_000) {
                // A second has passed

                // Play count down sound
                gameControl.countDownSound.play();

                // Re-render the game board
                printGameBoard();

                // Print time remaining until game starts
                printCountDownTime(count);

                // Print time left in game (will remain 2:00 for this animation timer)
                printTimeLeft(gameControl.getTimeRemaining());

                // Decrement seconds till game start
                count--;

                // Update last updated system time
                lastUpdate = currentNanoTime;
            }

            if (count == -1){
                // Reset the count down
                count = 3;

                // Start game
                gameControl.setPaused(false);
                gameGC.setGlobalAlpha(1);

                // Stop count down timer
                countDown.stop();

                // Start game timer and game screen refresh timer
                gameTimer.start();
                gameTick.start();
            }
        }
    };

    /**
     *  Game Timer
     *
     *  Updates the game control time remaining value every second
     *  Plays a sound every second in the final 10 seconds
     *  Stops the game if the timer has run out.
     */
    private AnimationTimer gameTimer = new AnimationTimer() {
        private long lastUpdate = 0 ;

        @Override
        public void handle(long currentNanoTime) {
            if (currentNanoTime - lastUpdate >= 1_000_000_000) {

                // A second has passed
                // Decrement the time remaining in game
                gameControl.setTimeRemaining(gameControl.getTimeRemaining()-1);
                lastUpdate = currentNanoTime;

            }
            if (gameControl.getTimeRemaining() <= 10) {

                // Within the last 10 seconds of game play
                // Play the countdown sound
                gameControl.countDownSound.play();

            }
            if (gameControl.getTimeRemaining() == 0){

                // Game time has run out.
                // Stop game timer and tick timer
                gameTimer.stop();
                gameTick.stop();

                // Set game as finished.
                gameControl.setFinished(true);
            }
        }
    };

    /**
     *  Game Tick Timer
     *
     *  Manages screen refresh every tick
     *  Passes current inputs to game control
     *  Prompts game control to run game tick
     *  Manages GUI at end of game
     */
    private AnimationTimer gameTick = new AnimationTimer() {
        public void handle(long currentNanoTime) {

            // Game control to act on input signals, ie paddle movement
            gameControl.handleInput(input);

            // Run game tick (logically move game elements, collisions, scoring etc)
            gameControl.tick();

            // Draw next frame
            printGameBoard();

            // Print game time remaining
            printTimeLeft(gameControl.getTimeRemaining());

            if (gameControl.isFinished()) {

                // Game is finished. Hence
                displayWinnerScreen();

                // and stop game timer and game tick
                gameTimer.stop();
                gameTick.stop();

            }
        }
    };

    // Helper function that displays an overlay on the game screen with the winning player
    // and an instruction the user
    private void displayWinnerScreen() {
        semiTransparentOverlay();
        gameGC.setFill(Paint.valueOf("WHITE"));
        gameGC.setFont(javafx.scene.text.Font.font("Verdana", 40));
        gameGC.fillText(gameControl.getWinnerAsString() + " wins! \n\nPress Enter To Continue.",width/2-200,220);
    }

    // Helper function that displays a semi transparent overlay on top of the currently displayed
    // game frame.
    private void semiTransparentOverlay() {
        gameGC.setGlobalAlpha(0.65);
        gameGC.setFill(Paint.valueOf("GREY"));
        gameGC.fillRect(0,0,width,height);
        gameGC.setGlobalAlpha(1);
    }

    // Helper function that manages scene transition and game preparation
    // Pass in the required fields and a new game will be displayed with the passed parameters
    //
    // Human players determines the number of human players to enable (ie how many AI's to enable)
    // Difficulty is used in determining AI difficulty and initial ball speed
    // Level determines the graphics/sprites used.
    private void setupGameWindowAndControl(int humanPlayers, int difficulty, LevelType level) {

        // Change to game screen
        window.setScene(gameScreen);

        // Prepare game with passed parameters
        gameControl = new GameControl(humanPlayers, difficulty, level);

        // Determine game background based on selected level.
        switch (level) {
            case ONE_MARS:
                gameBackground = new Image("images/marsBackground.png");
                break;
            case TWO_MOON:
                gameBackground = new Image("images/moonBackground.png");
                break;
            case THREE_EARTH:
                gameBackground = new Image("images/earthBackground.png");
                break;
            default:
                gameBackground = new Image("images/background.png");
        }

        // Print the first frame of the game
        printGameBoard();
    }

    // Helper function that prints the game board onto the game graphics content.
    // Assumes that the game screen is already displayed.
    private void printGameBoard() {

        // Remove previous frame
        gameGC.drawImage(gameBackground, 0, 0, width, height);

        // Print the game score
        printGameScore();


        // For every pixel,
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {

                // if there is a game object present and it is "alive"
                if ((gameControl.gameBoard.getAt(x, y) != null) && (gameControl.gameBoard.getAt(x, y).isAlive())) {
                    int objectWidth = gameControl.gameBoard.getAt(x, y).getWidth();
                    int objectHeight = gameControl.gameBoard.getAt(x, y).getHeight();

                    // draw that object
                    gameGC.drawImage(gameControl.gameBoard.getAt(x, y).getSprite(),
                            gameControl.gameBoard.getAt(x, y).getXPos(),
                            gameControl.gameBoard.getAt(x, y).getYPos(),
                            objectWidth,
                            objectHeight);

                    // and skip those pixels drawn.
                    y += objectHeight;
                }
            }
        }
    }

    // Helper function that prints the number of seconds remaining till the game begins
    private void printCountDownTime(int seconds) {
        gameGC.setFill(Paint.valueOf("WHITE"));
        gameGC.setFont(javafx.scene.text.Font.font("Verdana", 40));
        gameGC.fillText("Game starts in...",width/2-180,height/2-60);
        gameGC.setFont(javafx.scene.text.Font.font("Verdana", 70));
        gameGC.fillText(String.valueOf(seconds),width/2-20,height/2+20);
    }

    // Helper function that displays debugging info.
    // TODO Remove prior to final commit
    private void printDebugInfo() {
        // Currently configured to display ball position and velocity.
        gameGC.setFill(Paint.valueOf("WHITE"));
        gameGC.setFont(javafx.scene.text.Font.font("Verdana", 18));
        gameGC.fillText(String.valueOf(gameControl.getBall().getXPos()) + " , " + String.valueOf(gameControl.getBall().getYPos() + "\n" +
                gameControl.getBall().getXVelocity()) + " , " + String.valueOf(gameControl.getBall().getYVelocity()), width / 2, height/2);
    }

    // Helper function that determines the number of minutes and seconds remaining (from passed number
    // of seconds) and then displays this in the top middle of the game screen.
    private void printTimeLeft(int secondsRemaining){
        int minutes = secondsRemaining / 60;
        int seconds = secondsRemaining % 60;
        gameGC.setFill(Paint.valueOf("WHITE"));
        gameGC.setFont(javafx.scene.text.Font.font("Verdana", 18));
        if (seconds < 10) {
            gameGC.fillText(String.valueOf(minutes) + ":0" + String.valueOf(seconds) , width / 2 - 20, 40);
        } else {
            gameGC.fillText(String.valueOf(minutes) + ":" + String.valueOf(seconds), width / 2 - 20, 40);
        }
    }

    // Helper function that prints each players name, walls and score.
    private void printGameScore(){

	   // Setting font properties
       gameGC.setFill(Color.ORANGERED);
       Font theFont = Font.font( "Verdana", FontWeight.BOLD, 18 );
       gameGC.setFont( theFont );

       // Display player ones score
       String p1Points = "Player 1 \nShields : " + gameControl.getPlayer1().getWallsRemaining()
               + "\nPoints : " + gameControl.getPlayer1().getScore();
       gameGC.fillText(p1Points, 270.00, 30.00);
       gameGC.strokeText(p1Points, 270.00, 30.00);

       // Display player twos score
       String p2Points = "Player 2 \nShields : " + gameControl.getPlayer2().getWallsRemaining()
               + "\nPoints : " + gameControl.getPlayer2().getScore();
       gameGC.setFill(Color.DEEPSKYBLUE);
       gameGC.fillText(p2Points, 654.00, 30.00);
       gameGC.strokeText(p2Points, 654.00, 30.00);
       
       // Display player threes score
       String p3Points = "Player 3 \nShields : " + gameControl.getPlayer3().getWallsRemaining()
               + "\nPoints : " + gameControl.getPlayer3().getScore();
       gameGC.setFill(Color.CRIMSON);
       gameGC.fillText(p3Points, 270.00, 706.00);
       gameGC.strokeText(p3Points, 270.00, 706.00);
       
       // Display player fours score
       String p4Points = "Player 4 \nShields : " + gameControl.getPlayer4().getWallsRemaining()
               + "\nPoints : " + gameControl.getPlayer4().getScore();
       gameGC.setFill(Color.LIME);
       gameGC.fillText(p4Points, 654.00,706.00);
       gameGC.strokeText(p4Points, 654.00, 706.00);
   }

    // Helper function that pauses the game and displays a pause screen overlay.
    private void pause() {

        // Visually display pause screen
        semiTransparentOverlay();
        gameGC.setFill(Paint.valueOf("WHITE"));
        gameGC.setFont(javafx.scene.text.Font.font("Verdana", 40));
        gameGC.fillText("Pause. \nPress P to continue.\nPress Esc to exit.",width/2-200,height/2-150);

        // Pause all animation timers and set game to paused.
        gameControl.setPaused(true);
        gameTick.stop();
        countDown.stop();
        gameTimer.stop();
    }

    // Helper function that un pauses the game by initiating a 3 second count down.
    private void unPause() {
        gameControl.setPaused(false);
        countDown.start();
    }
}